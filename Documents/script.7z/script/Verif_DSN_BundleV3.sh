

#MSG_BODY=$TMP/fichierDSN.dat
. ~/.profile
user=`whoami`
affiche=$TMP/affiche.html
date=$(date +%d/%m/%Y" "%H:%M:%S)
	  
#fichresultatDSN="$TMP/Bundle_DSN"

fichresultatDSNOrigin="/admin/ibedoui/tmp/Bundle_DSN"
fichresultatDSN="/admin/ibedoui/tmp/Bundle_DSN_NEW"

#$EDSNCMD/client "bundle:list" |grep -v Active | grep -v Resolved >> $fichresultatDSN

#COMMENT THIS TO WORK and change fichresultatDSN et fichresultatDSNOrigin
$EDSNCMD/client "bundle:list" |grep -v Active | grep -v Resolved >> $fichresultatDSN

execution=$?
if [ $execution -eq 0 ];
then


nb=$(cat $fichresultatDSNOrigin |wc -l )

if [ $nb -gt 3 ]
then 

 #enlever le header et laisser seulement les bundles 
cat $fichresultatDSNOrigin | tail -n+4 >$fichresultatDSN 


touch $LOG/envoi_Prob_DSN_`date +'%Y%m%d'`




echo "<html>
<head>


<meta http-equiv='Content-Type' content='text/html; charset=UTF-8'>

</head>

<body align=center>
<style>
.responstable {
  margin: 1em 0;
  width: 50%;
  margin-left: auto;
  margin-right:auto;
  overflow: hidden;
  width:700 ;
  higth:500 ;
  color:#024457;
  border-radius: 8px;
  border: 10px solid #167F92;

}


}
.responstable tr {
  border: 2px solid #167F92 ;
}
.responstable tr:nth-child(odd) {
   border: 2px solid #167F92;
}
.responstable th {
  display: none;
  border: 2px solid ;
  background-color: #167F92;
  color: #167F92;
  padding: 1em;
}
.responstable th:first-child {
  display: table-cell;
  text-align: center;
}
.responstable th:nth-child(2) {
  display: table-cell;
}
.responstable th:nth-child(2) span {
}
  .responstable th:nth-child(2):after {
    display: none;
  }
}
.responstable td {
 border: 2px solid #167F92 ;
  word-wrap: break-word;
  max-width: 7em;
  background-color: #FFFFFF;
    filter: alpha(opacity=50);


  }
.responstable td:first-child {
  color: #024457;
  text-align: center;
  border-right: 2px solid #2FABC3;
}
@media (min-width: 480px) {
  .responstable td {
    border: 2px solid #14ACC9;
        color: red;

  }
}
.responstable th, .responstable td {
  text-align: left;
  margin: .5em 1em;
}
@media (min-width: 480px) {
  .responstable th, .responstable td {
    padding: 1em;
  }
}
body {
  padding: 0 2em;
  font-family: Arial, sans-serif;
  background: #ffffff;

  margin-top : 50px;



}

h1 {
  font-family: Verdana;
  font-weight: normal;
  text-align: center;
  color: #024457;
}
h1 span {
  color: #167F92;
}

</style>
" > $affiche


echo "Bonjour, <BR>" >>$affiche

echo "</BR>Ci-dessous le resultat du test edsn pour $user effectuée $date  </BR>">>$affiche

echo "</BR><center><u>
Il y a un probleme au niveau de ce(s) bundle(s)</u> </center>
">>$affiche


echo "</BR>
<table align="center" class="responstable" >
<tr>
<td> <b>"ID"</b>  </td>
<td> <b>"STATE"</b></td>
<td> <b>"Lvl"</b></td>
<td> <b>"Version"</b></td>
<td> <b>"Name" </b>  </td>

</tr>" >> $affiche


# *********************** PARTIE INSERTION DES BUNDLES 
while read ligne
 do
        id=`echo $ligne |awk -F "|"  '{print $1}'`
        state=`echo $ligne|awk -F "|"  '{print $2}'`
	lvl=`echo $ligne|awk -F "|"  '{print $3}'`
	version=`echo $ligne|awk -F "|"  '{print $4}'`
	name=`echo $ligne|awk -F "|"  '{print $5}'`
		echo " 
		<tr>
                <td>$id</td>
		<td>$state</td>
                <td>$lvl</td>
                <td>$version</td>
                <td>$name</td>
                </tr> "  >> $affiche

	

done < $fichresultatDSN

 

#cat Bundle_DSN | tail -n+4 | awk -F "|"  '{print $5}'

#***************************************

# fermer le fichier 

echo "
</table> <BR><BR>
">>$affiche



echo  "<u><b><font size="3">=> L'etat Starting et Waiting au niveau du bundle signifie qu'il est en cours de demarrage on doit attendre quelques minutes et verifier de nouveau l'etat  du bundle </font></b></u><BR><BR>">>$affiche
echo  "<u><b><font size="3">=> L'etat GracePeriod au niveau du bundle provque generallement un echec au niveau de l'EDSN ,on doit soit redemarrer ce bundle soit redemarrer la totalite du service EDSN  </font> </b></u><BR><BR>"  >>$affiche
echo "<u><b>=> On doit redemarrer le service EDSN si les autres solutions echouent </b></u><BR><BR>"  >>$affiche

echo "<BR>Cordialement, ">>$affiche

echo "
      </body>

      </html> " >> $affiche


reciever="ibrahim.bedoui@soprahr.com"
sender="Equipe_supervision@soprahr.com"
subject="alert dsn $user"

(
  echo To: $reciever
  echo From: $sender
  echo "Content-Type: text/html; "
  echo Subject: $subject
  echo
  cat $affiche
) | sendmail -t

fi

else 

MAIL_OK="ibrahim.bedoui@soprahr.com"
sujet="Alert :EDSN $user est DOWN"

sender="Equipe_de_Supervision@soprahr.com"
echo " Le service EDSN EST DOWN !!" |mail -s "$sujet" -S from="$sender"  "$MAIL_OK"
if [ $? -lt 0 ] ; then echo mail non  envoye
else echo "mail  envoye"
fi

exit 0
fi

