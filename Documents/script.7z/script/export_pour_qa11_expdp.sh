#!/bin/bash
#Debut de scripte 

echo " Lancement de scripte "

#declaration des variable variables
Extension=`date +%Y%m%d` 
dump=dump_mensuel_qa11
export $dump
export ORACLE_SID=QA112

echo $ORACLE_SID
echo " l'emplacement est ` pwd ` "
#plusieurs methodes des exports 
#nohup expdp userid=HR/2lGSi3qEE DIRECTORY=BACKUP ESTIMATE_ONLY=YES LOGFILE=$dump  SCHEMAS=HR &
#nohup expdp userid=HR/2lGSi3qEE DIRECTORY=BACKUP  LOGFILE=$dump  TABLES=ZD% DUMPFILE=$dump  &
#echo " l'export est decloncher "
#echo " le fichier log est ` cat | tail -f exp_sim11_20.log  ` "

#On va boucl� selon le choix de client

if [ $1 = 'DBD' ]
then
#dump=exp_dump_quotidien_qa11
#ssh -n  oracle@frsopslbdd018 ". ~/.bash_profile ;export ORACLE_SID=QA112;expdp userid=HR/2lGSi3qEE DIRECTORY=BACKUP  LOGFILE=${dump}.log  DUMPFILE=${dump}.dmp  TABLES=ZA%,ZC%,ZD%,ZE%,ZY% "

ssh -n  admin@frsopslbdd018 " cd  /backup_bdd18/QA11 ; sh expdp_aajimi.sh "

#ssh -n  oracle@frsopslbdd018 " sh /backup_bdd18/QA11/expdp_ahmed.sh "
#ssh -n  oracle@frsopslbdd018 " nohup expdp userid=HR/2lGSi3qEE DIRECTORY=BACKUP  LOGFILE=BACKUP:${dump}.log  DUMPFILE=${dump}.dmp  TABLES=ZA%,ZC%,ZD%,ZE%,ZY%,ZT%,ZU%,ZV%,Z5% & "
#ssh -n  oracle@frsopslbdd018 ". ~/.bash_profile ;export ORACLE_SID=QA112; expdp userid=HR/2lGSi3qEE DIRECTORY=BACKUP  LOGFILE=${dump}.log  TABLES=ZD% DUMPFILE=${dump}.dmp"
#nohup expdp userid=HR/2lGSi3qEE DIRECTORY=BACKUP  LOGFILE=DUMPTEST1.log  DUMPFILE=DUMPTEST1.dmp  TABLES=PP10 &"
echo " l'export est decloncher avec DBD "
fi


if [ $1 = 'ZX' ]
then
#dump=exp_dump_quotidien_qa11_ZX-${Extension}

#nohup expdp userid=HR/2lGSi3qEE DIRECTORY=BACKUP  LOGFILE=DUMPTEST1.log  DUMPFILE=DUMPTEST1.dmp  TABLES=PP10 &"

ssh -n  admin@frsopslbdd018 " sh /backup_bdd18/QA11/expdp_aajimi.sh "
#ssh -n  oracle@frsopslbdd018 ". ~/.bash_profile ;export ORACLE_SID=QA112; expdp userid=HR/2lGSi3qEE DIRECTORY=BACKUP ESTIMATE_ONLY=YES LOGFILE=${dump}.log DUMPFILE=${dump}.dmp  TABLES=ZX% QUERY='ZX00:"where nudoss in (select nudoss from zx00 where perpai='MT$(date "+%Y%m")')"' & "
echo " l'export est decloncher avec ZX "
fi

sleep 240
#sleep 60
#ssh -n admin@frsopslbdd018 "  compress /backup_bdd18/QA11/${dump}.dmp "
#ssh -n admin@frsopslbdd018 "  compress /backup_bdd18/QA11/${dump}-ZX.dmp "
ssh -n admin@frsopslbdd018 "  compress /backup_bdd18/QA11/ahmed.dmp "
sleep 240
#sleep 60 
#partie de deployer le dump dans le serveur applicative
#cd ou repetoir qu'on doit faire le copie

cd /espacetemp/tmp
rm -f *.dmp
rm -f *.log

#scp -pr admin@frsopslbdd018:/backup_bdd18/QA11/${dump}.dmp.Z  .
scp -pr admin@frsopslbdd018:/backup_bdd18/QA11/ahmed.dmp.Z  .
#scp -pr admin@frsopslbdd018:/backup_bdd18/QA11/${dump}-ZX.dmp.Z  .
sleep 120
#sleep 60




#partie  complete de deployement des fichier ftp apartir de serveur applicative

#compress ${dump}.dmp

#openssl dgst -md5 $dump.Z  > $dump.Z.txt
sftp  appautqa@frsopslftpv02 <<eot
user appautqa "nqh22DUf?"
cd /OUT/DUMP
mdelete ${TYPDUMP}*
binary
#put ${dump}.dmp.Z
put ahmed.dmp.Z
#put ${dump}-ZX.dmp.Z
bye
eot

 #usage "Backup completed successfully. RC=0"
 #  usage "Dump file is : ${DUMP}.Z"
   CODE_RETOUR=0


#fin_script
#if [ "$CODE_RETOUR" = "1" ]; then
 # exit 1
#else
  #rm ${DUMP}.Z
  #rm ${DUMP}.hahsh_md5.txt
 # rm -f ${PARMEXP}
#  exit 0
#fi

#sftp appautqa@frsopslftpv02





