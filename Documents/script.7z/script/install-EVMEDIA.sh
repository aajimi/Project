# AUTEUR : Gabriel Poncherot (PRODOPS IDKA FR)
# 05/03/2015
# script de prima-installation de evmedia
# Delivery Pack = ATIJ-X.Y.ZZZ  (exemple ATIJ-1.0.000)
# 		X = version majeure d'ATIJ
# 		Y = version mineure d'ATIJ
# 		ZZZ = version de maintenance d'ATIJ
# 3 composants :
# 	evmedia-version.tar.gz = 			serveur bas� sur le m�me socle technologique que l'Espace DSN.
#										Il dispose lui aussi d'une base de donn�es d�di�e : la BDSAT.
# 	hraccess-sat-feature-version.kar = 	C'est l'add-on pour evMedia permettant de se connecter � un environnement HR Access.
#										Il est de m�me nature que le connecteur Produit de l'Espace DSN.
#	hr-evmedia-gateway-version.war = 	Il s'agit d'une application web pour HRa Space a installer sous tomweb.
#										Elle permet d'int�grer des donn�es d'evMedia dans le Client Riche.
# VERSION_EVM : Version de l'Evmedia (exemple 1.0.0  pour evmedia-1.0.0)
# VERSION_KAR : Version du fichier kar (exemple 1.0.0 pour hraccess-sat-feature-1.0.0.kar)
# VERSION_EVM_WEB : Version de l'appli web evmedia (exemple hr-evmedia-gateway-1.0.0.war)
. $HOME/.profile
export VERSIONDP=$1

export DELIVERYPACK=ATIJ
export MODULE=evmedia
export CONNECTEUR=hraccess-sat-feature
export EVM_WEB=hr-evmedia-gateway
export REP_CIBLE=$SIGACS/EVMED
export EVMED_HOME=$REP_CIBLE/evmedia-home
export REP_DEPOT=/admin/depot/DSN

# conditions d'execution du script
# renseignement de la version XYZZZ du delivery PACK ATIJ sans les points est obligatoire
if [ "${VERSIONDP}" = "" ]
then
        echo "Nouvelle Version du Delivery Pack ${DELIVERYPACK} XYZZZ manquante (exemple 10000 pour ATIJ-1.0.000-HRA)"
        exit 1
fi
# le delivery pack ATIJ-XYZZZ doit �tre pr�sent dans le d�p�t
if  [ ! -d "${REP_DEPOT}/${DELIVERYPACK}-${VERSIONDP}" ]
  then
        echo "Nouvelle Version du Delivery Pack inconnue dans le depot ${REP_DEPOT}/${DELIVERYPACK}-${VERSIONDP}"
        exit 1
fi

# pour une prima-installation, le r�pertoire d'installation ne doit pas exister pour eviter des �crasements
# si besoin de relancer, merci de pr�alablement supprimer le r�pertoire cible 
if [ -e "${REP_CIBLE}" ]
  then
        echo "Le module $MODULE semble deja present, merci de supprimer $REP_CIBLE pour une relance"
        exit 1
  else 
  mkdir ${REP_CIBLE}
fi 

# la variable $Slice doit �tre connue pour l'habillage des ports.
if [ "${Slice}" = "" ]
then
        echo "attention, l'habillage s'appuie sur la variable $Slice pour les habillages des ports. donc � �tablir prealablement"
        exit 1
fi

#CIMPA
if [ "${Slice}" = "102" ]
then
export Slice=02
fi
#HSM
if [ "${Slice}" = "121" ]
then
export Slice=21
fi
#HSM
if [ "${Slice}" = "111" ]
then
export Slice=11
fi
#COOPER
if [ "${Slice}" = "161" ]
then
export Slice=61
fi


###################################################
echo " ***********************************************************************************************************************"
echo " *   version delivery-pack ${DELIVERYPACK} = ${VERSIONDP}"
echo " *   depot sous /admin/depot/DSN/${DELIVERYPACK}-${VERSIONDP}"
#---- on r�cup�re les versions des composants
export VERSION_EVM=$(ls ${REP_DEPOT}/${DELIVERYPACK}-${VERSIONDP}/${MODULE}* | awk -F"-" '{print $NF}' | awk -F".tar.gz" '{print $1}')
export VERSION_KAR=$(ls ${REP_DEPOT}/${DELIVERYPACK}-${VERSIONDP}/${CONNECTEUR}* | awk -F"-" '{print $NF}' | awk -F".kar" '{print $1}')
export VERSION_EVM_WEB=$(ls ${REP_DEPOT}/${DELIVERYPACK}-${VERSIONDP}/${EVM_WEB}* | awk -F"-" '{print $NF}' | awk -F".war" '{print $1}')
echo " *   version serveur ${MODULE} = ${VERSION_EVM}"
echo " *   version connecteur ${CONNECTEUR} = ${VERSION_KAR}"
echo " *   version application web ${EVM_WEB} = ${VERSION_EVM_WEB}"
echo " ***********************************************************************************************************************"

#####################################################
# Installation nouvelle version
# je recupere du depot sous /admin/depot/DSN le produit et le copie dans repertoire $REP_CIBLE
echo "- Installation $MODULE-${VERSION_EVM} commence"
echo " *   le module $MODULE-${VERSION_EVM} du delivery-pack ${DELIVERYPACK}-${VERSIONDP} sera installe sous $REP_CIBLE"
cp ${REP_DEPOT}/${DELIVERYPACK}-${VERSIONDP}/${MODULE}-${VERSION_EVM}.tar.gz ${REP_CIBLE}
cp ${REP_DEPOT}/${DELIVERYPACK}-${VERSIONDP}/${CONNECTEUR}-${VERSION_KAR}.kar ${REP_CIBLE}
# copie de l'appli web sous tomweb
cp ${REP_DEPOT}/${DELIVERYPACK}-${VERSIONDP}/${EVM_WEB}-${VERSION_EVM_WEB}.war ${SIGACS}/tomweb/webapps/${EVM_WEB}.war
# dezippage du evmedia
cd ${REP_CIBLE}
tar -zxf ${MODULE}-${VERSION_EVM}.tar.gz
chmod -R g+w ${MODULE}-${VERSION_EVM}
rm -f ${MODULE}-${VERSION_EVM}.tar.gz
cd ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/bin
rm *.bat
# mise a jour JAVA_HOME dans setenv
echo "JAVA_HOME=/etc/alternatives/jre_1.8.0" >> ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/bin/setenv
echo "export JAVA_HOME" >> ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/bin/setenv
echo "JAVA_OPTS=\"-Xms1024M -Xmx4096M\"" >> ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/bin/setenv
echo "export JAVA_OPTS" >> ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/bin/setenv

echo "- installation $MODULE-${VERSION_EVM} finie" 
# demarrage de edsn 
echo "- demarrage $MODULE-${VERSION_EVM} pour creation ${EVMED_HOME}"
cd ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/bin
./start clean
sleep 60 
echo "fin attente demmarrage"
./stop
sleep 15
echo "arret  $MODULE-${VERSION_EVM}"

#copie des connecteurs evmedia et oracle
cp ${REP_DEPOT}/${DELIVERYPACK}-${VERSIONDP}/${CONNECTEUR}-${VERSION_KAR}.kar ${EVMED_HOME}/work/addons
cp ${REP_DEPOT}/ojdbc6.jar ${EVMED_HOME}/work/addons

# configurations
echo "configuration ${EVMED_HOME}/conf/com.soprahr.evm.govdata.cfg"
echo "param�trage smicHoraire.202001=10.15"
echo "param�trage pmss.202001=3428"
echo > ${EVMED_HOME}/conf/com.soprahr.evm.govdata.cfg
echo "smicHoraire.202001=10.15" >> ${EVMED_HOME}/conf/com.soprahr.evm.govdata.cfg
echo "pmss.202001=3428" >> ${EVMED_HOME}/conf/com.soprahr.evm.govdata.cfg

echo "configuration ${EVMED_HOME}/conf/com.soprahr.evm.sat.license.cfg"
echo "param�trage ij=true"
echo > ${EVMED_HOME}/conf/com.soprahr.evm.sat.license.cfg
echo "ij=true" >> ${EVMED_HOME}/conf/com.soprahr.evm.sat.license.cfg

echo "configuration ${EVMED_HOME}/conf/com.soprahr.evm.edsnlink.cfg" 
echo > ${EVMED_HOME}/conf/com.soprahr.evm.edsnlink.cfg
if [ "$Prefix" = "pr" ] || [ "$EnvType" = "P1" ] || [ "$EnvType" = "P2" ]
    then
	echo > ${EVMED_HOME}/conf/com.soprahr.evm.edsnlink.cfg
	echo "baseUri=http://localhost:231$Slice/" >> ${EVMED_HOME}/conf/com.soprahr.evm.edsnlink.cfg
fi
if [ "$EnvType" = "QA" ]
    then
	echo > ${EVMED_HOME}/conf/com.soprahr.evm.edsnlink.cfg
	echo "baseUri=http://localhost:131$Slice/" >> ${EVMED_HOME}/conf/com.soprahr.evm.edsnlink.cfg
fi 
if [ "$EnvType" = "DV" ]
	then
	echo > ${EVMED_HOME}/conf/com.soprahr.evm.edsnlink.cfg
	echo "baseUri=http://localhost:331$Slice/" >> ${EVMED_HOME}/conf/com.soprahr.evm.edsnlink.cfg
fi 
if [ ! "$Prefix" = "pr" ] && [ ! "$EnvType" = "P1" ] && [ ! "$EnvType" = "P2" ] && [ ! "$EnvType" = "QA" ] && [ ! "$EnvType" = "DV" ]
	then
	#cas possibles des MPS hors production
	echo "variable Prefix=$Prefix"
	echo > ${EVMED_HOME}/conf/com.soprahr.evm.edsnlink.cfg
	echo "baseUri=http://localhost:131$Slice/" >> ${EVMED_HOME}/conf/com.soprahr.evm.edsnlink.cfg
fi

#configuration connexion BDSAT / HRA
. call_zcn
URLJDBC="$(tnsping $ORACLE_SID | grep "DESCRIPTION " | awk -F"Attempting to contact " '{print $2}')"
echo > ${EVMED_HOME}/conf/com.soprahr.evm.datasource.cfg
echo "datasource.jdbc.driver=oracle.jdbc.OracleDriver" >> ${EVMED_HOME}/conf/com.soprahr.evm.datasource.cfg
echo "datasource.jdbc.url=jdbc:oracle:thin:@$URLJDBC" >> ${EVMED_HOME}/conf/com.soprahr.evm.datasource.cfg
echo "datasource.user=${HRUSER}" >> ${EVMED_HOME}/conf/com.soprahr.evm.datasource.cfg
echo "datasource.password=${HRPSWD}" >> ${EVMED_HOME}/conf/com.soprahr.evm.datasource.cfg

echo > ${EVMED_HOME}/conf/com.soprahr.evm.sat.hraccess.datasource.cfg
echo "datasource.jdbc.driver=oracle.jdbc.OracleDriver" >> ${EVMED_HOME}/conf/com.soprahr.evm.sat.hraccess.datasource.cfg
echo "datasource.jdbc.url=jdbc:oracle:thin:@$URLJDBC" >> ${EVMED_HOME}/conf/com.soprahr.evm.sat.hraccess.datasource.cfg
echo "datasource.user=${HRUSER}" >> ${EVMED_HOME}/conf/com.soprahr.evm.sat.hraccess.datasource.cfg
echo "datasource.password=${HRPSWD}" >> ${EVMED_HOME}/conf/com.soprahr.evm.sat.hraccess.datasource.cfg


#mise a jour des timeout
echo "- mise a jour timeout ssh a 21100000ms"
sed -i "s:sshIdleTimeout =.*:sshIdleTimeout = 21100000:g" ${EVMED_HOME}/conf/org.apache.karaf.shell.cfg
echo "- mise a jour timeout web edsn a 180 min"
sed -i "s:org.ops4j.pax.web.session.timeout=.*:org.ops4j.pax.web.session.timeout=180:g" ${EVMED_HOME}/conf/org.ops4j.pax.web.cfg

#mise a jour des ports tcp
#ports rmi org.apache.karaf.management.cfg
#port ssh org.apache.karaf.shell.cfg
#port http org.ops4j.pax.web.cfg
#port shutdown custom.properties
if [ "$Prefix" = "pr" ] || [ "$EnvType" = "P1" ] || [ "$EnvType" = "P2" ]
    then
	echo "karaf.shutdown.port=274${Slice}" >> ${EVMED_HOME}/conf/custom.properties
    sed -i "s:rmiRegistryPort =.*:rmiRegistryPort = 272${Slice}:g" ${EVMED_HOME}/conf/org.apache.karaf.management.cfg
    sed -i "s:rmiServerPort =.*:rmiServerPort = 273${Slice}:g" ${EVMED_HOME}/conf/org.apache.karaf.management.cfg 
    sed -i "s:sshPort =.*:sshPort = 271${Slice}:g" ${EVMED_HOME}/conf/org.apache.karaf.shell.cfg 
    sed -i "s:org.osgi.service.http.port=.*:org.osgi.service.http.port=270${Slice}:g" ${EVMED_HOME}/conf/org.ops4j.pax.web.cfg
fi
if [ "$EnvType" = "QA" ]
      then
	echo "karaf.shutdown.port=174${Slice}" >> ${EVMED_HOME}/conf/custom.properties
    sed -i "s:rmiRegistryPort =.*:rmiRegistryPort = 172${Slice}:g" ${EVMED_HOME}/conf/org.apache.karaf.management.cfg
    sed -i "s:rmiServerPort =.*:rmiServerPort = 173${Slice}:g" ${EVMED_HOME}/conf/org.apache.karaf.management.cfg 
    sed -i "s:sshPort =.*:sshPort = 171${Slice}:g" ${EVMED_HOME}/conf/org.apache.karaf.shell.cfg 
    sed -i "s:org.osgi.service.http.port=.*:org.osgi.service.http.port=170${Slice}:g" ${EVMED_HOME}/conf/org.ops4j.pax.web.cfg 
fi 
if [ "$EnvType" = "DV" ]
      then
	echo "karaf.shutdown.port=374${Slice}" >> ${EVMED_HOME}/conf/custom.properties
    sed -i "s:rmiRegistryPort =.*:rmiRegistryPort = 372${Slice}:g" ${EVMED_HOME}/conf/org.apache.karaf.management.cfg
    sed -i "s:rmiServerPort =.*:rmiServerPort = 373${Slice}:g" ${EVMED_HOME}/conf/org.apache.karaf.management.cfg 
    sed -i "s:sshPort =.*:sshPort = 371${Slice}:g" ${EVMED_HOME}/conf/org.apache.karaf.shell.cfg 
    sed -i "s:org.osgi.service.http.port=.*:org.osgi.service.http.port=370${Slice}:g" ${EVMED_HOME}/conf/org.ops4j.pax.web.cfg
fi 
if [ ! "$Prefix" = "pr" ] && [ ! "$EnvType" = "P1" ] && [ ! "$EnvType" = "P2" ] && [ ! "$EnvType" = "QA" ] && [ ! "$EnvType" = "DV" ]
	then
	#cas possible des MPS hors prod
	echo "variable Prefix=$Prefix"
	echo "karaf.shutdown.port=174${Slice}" >> ${EVMED_HOME}/conf/custom.properties
    sed -i "s:rmiRegistryPort =.*:rmiRegistryPort = 172${Slice}:g" ${EVMED_HOME}/conf/org.apache.karaf.management.cfg
    sed -i "s:rmiServerPort =.*:rmiServerPort = 173${Slice}:g" ${EVMED_HOME}/conf/org.apache.karaf.management.cfg 
    sed -i "s:sshPort =.*:sshPort = 171${Slice}:g" ${EVMED_HOME}/conf/org.apache.karaf.shell.cfg 
    sed -i "s:org.osgi.service.http.port=.*:org.osgi.service.http.port=170${Slice}:g" ${EVMED_HOME}/conf/org.ops4j.pax.web.cfg 
fi

#initialisation fichier confid users.xml
echo "mise a jour users.xml"
echo "<users>" > ${EVMED_HOME}/conf/users.xml
echo "<user id="admin" firstName="Jean" lastName="Admin" password="admin">" >> ${EVMED_HOME}/conf/users.xml
echo "<group>admin</group>" >> ${EVMED_HOME}/conf/users.xml
echo "</user>" >> ${EVMED_HOME}/conf/users.xml
echo "<user id="superij" firstName="Jean" lastName="Superviseur" password="superij">" >> ${EVMED_HOME}/conf/users.xml
echo "<group>superviseurIJ</group>" >> ${EVMED_HOME}/conf/users.xml
echo "</user>" >> ${EVMED_HOME}/conf/users.xml
echo "</users>" >> ${EVMED_HOME}/conf/users.xml
echo "fichier users.xml initialis�"
		

#BDSAT
CONNECT_STRING=`$INIT_PATH/shell/getConnectString.sh`

#controle existence TBS et creation si absent
echo "controle existence TBS de la BDSN"
sqlplus $CONNECT_STRING << EOF 
spool $TMP/testBDSAT.tmp
select '##@',tablespace_name from dba_data_files where tablespace_name='BDSAT_DATA';
spool off
EOF

if [ `grep "^##@" $TMP/testBDSAT.tmp | wc -l` -eq 0 ]
	then
	echo "Le tablespace BDSAT_DATA n'existe pas."
	rm -f $TMP/testBDSAT.tmp 
	echo "CREATE  BIGFILE TABLESPACE "BDSAT_INDEX" DATAFILE SIZE 100M" > ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/ddl/create/oracle/OSD.bdsat.tablespace.oracle.create.sql
	echo "AUTOEXTEND ON NEXT 300M MAXSIZE UNLIMITED" >> ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/ddl/create/oracle/OSD.bdsat.tablespace.oracle.create.sql
	echo "LOGGING ONLINE PERMANENT BLOCKSIZE 8192" >> ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/ddl/create/oracle/OSD.bdsat.tablespace.oracle.create.sql
	echo "EXTENT MANAGEMENT LOCAL AUTOALLOCATE SEGMENT SPACE MANAGEMENT AUTO;" >> ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/ddl/create/oracle/OSD.bdsat.tablespace.oracle.create.sql
	echo "CREATE  BIGFILE TABLESPACE "BDSAT_DATA" DATAFILE SIZE 100M" >> ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/ddl/create/oracle/OSD.bdsat.tablespace.oracle.create.sql
	echo "AUTOEXTEND ON NEXT 300M MAXSIZE UNLIMITED" >> ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/ddl/create/oracle/OSD.bdsat.tablespace.oracle.create.sql
	echo "LOGGING ONLINE PERMANENT BLOCKSIZE 8192" >> ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/ddl/create/oracle/OSD.bdsat.tablespace.oracle.create.sql
	echo "EXTENT MANAGEMENT LOCAL AUTOALLOCATE SEGMENT SPACE MANAGEMENT AUTO;" >> ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/ddl/create/oracle/OSD.bdsat.tablespace.oracle.create.sql
	echo "COMMIT;" >> ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/ddl/create/oracle/OSD.bdsat.tablespace.oracle.create.sql
	echo "creation TBS BDSAT_DATA et BDSAT_INDEX"
	cat OSD.bdsat.tablespace.oracle.create.sql | sqlplus $CONNECT_STRING > $LOG/OSD.bdsat.tbs.oracle.create.log
	else
	echo "Le tablespace BDSAT_DATA existe."
fi

# suppression preventive des tables de la BDSAT
cd  ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/ddl/drop/oracle
CONNECT_STRING=`$INIT_PATH/shell/getConnectString.sh`
echo "drop des tables de la BDSAT - async.oracle.drop.sql"
cat async.oracle.drop.sql | sqlplus $CONNECT_STRING > $LOG/async.oracle.drop.log
echo "drop des tables de la BDSAT - evmedia.oracle.drop.sql"
cat evmedia.oracle.drop.sql | sqlplus $CONNECT_STRING > $LOG/evmedia.oracle.drop.log

# creation tables de la BDSAT
cd  ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/ddl/create/oracle
echo "creation des tables de la BDSAT - evmedia.oracle.create.sql"
cat evmedia.oracle.create.sql | sqlplus $CONNECT_STRING > $LOG/evmedia.oracle.create.log
echo "creation des tables de la BDSAT - async.oracle.create.sql"
cat async.oracle.create.sql | sqlplus $CONNECT_STRING > $LOG/async.oracle.create.log
 
# demarrage du serveur evmedia
echo "- demarrage $MODULE ${VERSION_EVM}"
cd ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/bin
./start clean
sleep 180
echo "fin attente demmarrage"

cd ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/bin
./client "addon:list"
./client "bundle:list"

#mise a jour alias dsnconf dsnlog dsnbin
if [ $(grep -c evmconf $HOME/.profile) -eq 0 ]
	then
    echo "alias evmconf='cd \$SIGACS/${EVMED_HOME}/conf;ls -rtl'" >> $HOME/.profile
    else
    sed -i "s:alias evmconf=.*:alias evmconf='cd \$SIGACS/${EVMED_HOME}/conf;ls -rtl':g" $HOME/.profile
fi
if [ $(grep -c evmlog $HOME/.profile) -eq 0 ]
    then
    echo "alias evmlog='cd \$SIGACS/${EVMED_HOME}/logs;ls -rtl'" >> $HOME/.profile
    else
    sed -i "s:alias evmlog=.*:alias evmlog='cd \$SIGACS/${EVMED_HOME}/logs;ls -rtl':g" $HOME/.profile
fi
if [ $(grep -c evmbin $HOME/.profile) -eq 0 ]
    then
    echo "alias evmbin='cd \$SIGACS/EVMED/${MODULE}-${VERSION_EVM}/bin;ls -rtl'" >> $HOME/.profile
    echo "EVMCMD=\$SIGACS/EVMED/${MODULE}-${VERSION_EVM}/bin" >> $HOME/.profile
    else
    sed -i "s:alias evmbin=.*:alias evmbin='cd \$SIGACS/EVMED/${MODULE}-${VERSION_EVM}/bin;ls -rtl':g" $HOME/.profile    
    sed -i "s:EVMCMD=.*:EVMCMD=\$SIGACS/EVMED/${MODULE}-${VERSION_EVM}/bin:g" $HOME/.profile
fi

# demarrage du serveur evmedia
echo "- demarrage $MODULE ${VERSION_EVM}"
cd ${REP_CIBLE}/${MODULE}-${VERSION_EVM}/bin
./start clean
./client "addon:list"
./client "bundle:list"

#purge
rm ${REP_CIBLE}/*.tar.gz
rm ${REP_CIBLE}/*.kar

echo "�tapes suivantes :"
echo "*********************"
echo "mettre � jour l'objet topologie avec param�tres suivants"
echo "param�tres:" 
echo "    evmedia.rest.url=http://frsopslapp009-vip.soprahronline.sopra:34139/rest" 
echo "    evmedia.sat.allowedRoles=ALLHRLO"
echo "mettre a jour le tomweb en demmarrage java 1.8"
echo "FIN"
