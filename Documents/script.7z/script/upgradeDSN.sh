#
# MIGRATION_ESPACE_DSN
#
# VERSION_EDSN : Version de l'Espace DSN exemple 1.1.5
# VERSION_KAR : Version du fichier kar 
# Owner : Gabriel Poncherot
# manuel : consigne maia 385
# 04/03/2015
########################################################
# modifications script
# date/owner/changement
# 13/03/2019 / GPO / chmod 775 sous work/addons
# 25/03/2019 / GPO/ traitement particulier install 50028 si source 50027
# 12/03/2020 / GPO / cure amaigrisssement du script, retrait des exceptions obsoletes
########################################################
. $HOME/.profile_73
export VERSIONDSN=$1
export MODULE=edsn
if [ "${VERSIONDSN}" = "" ]
then
        echo "Nouvelle Version du Delivery Pack manquante"
        exit 1
fi
if [ ! -d /etc/alternatives/jre_1.8.0 ]
then	
	echo "le JAVA_HOME=/etc/alternatives/jre_1.8.0 n existe pas . merci de d�rminer votre repertore java 1.8"
	exit 1
fi
###################################################
if [ `hostname` = "frsopslapp058" ] || [ `hostname` = "frsopslapp057" ] || [ `hostname` = "frsopslapp065" ] || [ `hostname` = "frsopslapp066" ] 
then
#CASA/CACIB/LCL/MBDA
echo "on rentre dans la boucle des DSN type IBM (CASA/CACIB/LCL/MBDA)"
        export REP_CIBLE=$SIGACS/dsn
else
        export REP_CIBLE=$SIGACS/EDSN2
fi
# cas ASPEN multitenant
#if [ "$EnvType$Slice" = "QA33" ] || [ "$EnvType$Slice" = "QA73" ] || [ "$EnvType$Slice" = "QA74" ] || [ "$EnvType$Slice" = "P133" ]
#then
 #       echo "merci de prendre contact avec gabriel poncherot pour la mise en place DSN ASPEN, Inforsud, Axway"
  #      exit 1
#fi

echo " ***********************************************************************************************************************"
echo " *   le module $MODULE du delivery-pack ${VERSIONDSN} sera installe sous $REP_CIBLE"
. $INIT_PATH/shell/function.sh
#---- on r�cup�re les versions de eDSN
GetVarProfile dsnbin
export VERSION_OLD="$(echo $PROFVAR | awk -F"/" '{print $(NF - 1)}' | awk -F"-" '{print $2}')"
export VERSION_NEW=$(ls /admin/depot/DSN/HRA-${VERSIONDSN}/${MODULE}* | awk -F"-" '{print $NF}' | awk -F".tar.gz" '{print $1}')
GetVarProfile rldbin
export VERSION_RLD_OLD="$(echo $PROFVAR | awk -F"/" '{print $(NF - 1)}' | awk -F"-" '{print $4}')"
export VERSION_RLD_NEW=$(ls /admin/depot/DSN/HRA-${VERSIONDSN}/*.zip | awk -F"-" '{print $(NF - 1)}')
export VERSION_KAR=$(ls /admin/depot/DSN/HRA-${VERSIONDSN}/hraccess-feature* | awk -F"-" '{print $NF}' | awk -F".kar" '{print $1}')
vdsnval=$(ls /admin/depot/DSN/DSNVAL/*.kar | awk -F"-" '{print $NF}' | awk -F".kar" '{print $1}')
export VERSION_DSNVAL_NEW=$(echo "$vdsnval" | awk '{print $NF}')
export REP_DEPOT=/admin/depot/DSN
echo " *   ancienne version $MODULE = $VERSION_OLD"
echo " *   nouvelle version $MODULE = $VERSION_NEW"
echo " *   ancienne version reloader = $VERSION_RLD_OLD"
echo " *   nouvelle version reloader = $VERSION_RLD_NEW"
echo " ***********************************************************************************************************************"

if  [ ! -d "${REP_DEPOT}/HRA-${VERSIONDSN}" ]
  then
        echo "Nouvelle Version du Delivery Pack inconnue dans le depot ${REP_DEPOT}/HRA-${VERSIONDSN}"
        exit 1
fi

#if 	[ ! $(echo "${VERSION_NEW}" | cut -c1,3,5) -gt $(echo "${VERSION_OLD}" | cut -c1,3,5) ]
#	then	
#		echo "La Version $VERSIONDSN est deja installe ou bien une version plus récente est installee"
#		exit 1
#fi
if [ -d "$REP_CIBLE/${MODULE}-${VERSION_NEW}" ]
then 
	echo "La Version $VERSIONDSN est deja installe"
exit 1
fi
##############


# Nettoyage et pr�alable
rm -f ${REP_CIBLE}/*.tar.gz
rm -f ${REP_CIBLE}/*.kar

# 1 Arr�t de l'Espace DSN
echo "- Arret en cours de $MODULE pour $EnvType "
export ACTION="Fermeture"
cd $REP_CIBLE/${MODULE}-${VERSION_OLD}/bin
./stop
sleep 5
attente=12
#processus=$(ps -fu $(whoami) | grep jre_1.8.0/bin/java | grep -w UnlockDiagnosticVMOptions | grep -v EDSN | awk '{print $2}')
processus=$(ps -fu $(whoami) | grep java | grep -w Dedsn.home | grep -v grep | awk '{print $2}')
processus2=$(ps -fu $(whoami) | grep edsn | grep -w 'edsn server' | grep -v grep | awk '{print $2}')
if [ -n "$processus" ] || [ -n "$processus2" ]
then
  while [ -n "$processus" ] || [ -n "$processus2" ] && [ $attente -gt 0 ]
  do
    sleep 5
    echo "Attente de la fin du processus..."
    #processus=$(ps -fu $(whoami) | grep jre_1.8.0/bin/java | grep -w UnlockDiagnosticVMOptions | grep -v EDSN | awk '{print $2}')
    processus=$(ps -fu $(whoami) | grep java | grep -w Dedsn.home | grep -v grep | awk '{print $2}')
    processus2=$(ps -fu $(whoami) | grep edsn | grep -w 'edsn server' | grep -v grep | awk '{print $2}')

    (( attente = attente - 1 ))
  done

  if [ -n "$processus" ] || [ -n "$processus2" ]
  then
    echo "Le processus web sur $serveur_web tourne encore, je le kill!"
    kill -9 $processus $processus2
  fi
fi
echo "- $MODULE est arrete"


# 2 Installation nouvelle version
# je recupere du depot sous /admin/depot/DSN le produit et le copie dans repertoire EDSN
# je dezzipe le module edsn 
echo "- Installation $MODULE ${VERSION_NEW} commence"
cp -f ${REP_DEPOT}/HRA-${VERSIONDSN}/${MODULE}-${VERSION_NEW}.tar.gz ${REP_CIBLE}
cp -f ${REP_DEPOT}/HRA-${VERSIONDSN}/hraccess-feature-${VERSION_KAR}.kar ${REP_CIBLE}
cp -f ${REP_DEPOT}/DSNVAL/dsnval-feature-${VERSION_DSNVAL_NEW}.kar ${REP_CIBLE}
cd ${REP_CIBLE}
tar -zxf ${MODULE}-${VERSION_NEW}.tar.gz
chmod -R 775 ${MODULE}-${VERSION_NEW}
cd ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/bin
rm -f *.bat

if  [ $(grep -c JAVA_HOME\=\/etc\/alternatives\/jre_1.8.0 ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/bin/setenv) -ne 0 ]
	then
		echo "la variable JAVA_HOME est bien positionnee dans setenv de dsnbin"
	else
		echo "JAVA_HOME=/etc/alternatives/jre_1.8.0" >> ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/bin/setenv
		echo "export JAVA_HOME" >> ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/bin/setenv                        
		echo " ajout variable JAVA_HOME=/etc/alternatives/jre_1.8.0 dans setenv de dsnbin"
		case `hostname` in
                frsopslapp043)
		echo " ajout variable JAVA_OPTS a 8 Go dans setenv de dsnbin"
		echo "JAVA_OPTS=\"-Xms1024M -Xmx8192M\"" >> ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/bin/setenv
		echo "export JAVA_OPTS" >> ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/bin/setenv
		;;
		*)
                echo " ajout variable JAVA_OPTS a 4 Go dans setenv de dsnbin"
                echo "JAVA_OPTS=\"-Xms1024M -Xmx4096M\"" >> ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/bin/setenv
                echo "export JAVA_OPTS" >> ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/bin/setenv
                ;;
		esac
fi
echo "- installation $MODULE ${VERSION_NEW} finie" 

#mise a jour des timeout au passage
echo "- mise a jour timeout ssh a 21100000ms"
sed -i "s:sshIdleTimeout =.*:sshIdleTimeout = 21100000:g" $REP_CIBLE/${MODULE}-home/conf/org.apache.karaf.shell.cfg
echo "- mise a jour timeout web edsn a 180 min"
sed -i "s:org.ops4j.pax.web.session.timeout=.*:org.ops4j.pax.web.session.timeout=180:g" $REP_CIBLE/edsn-home/conf/org.ops4j.pax.web.cfg

if  [ $(grep -c altTitle $REP_CIBLE/${MODULE}-home/conf/com.soprahr.edsn.ui.webapp.cfg) -ne 0 ]
	then
		sed -i "s:altTitle=.*:altTitle=$EnvName DSN-${VERSIONDSN} DSNval-${VERSION_DSNVAL_NEW}:g" $REP_CIBLE/${MODULE}-home/conf/com.soprahr.edsn.ui.webapp.cfg
		echo "mise a jour du parametre altTitle dans le fichier com.soprahr.edsn.ui.webapp.cfg" 
	else
		echo "altTitle=$EnvName DSN-${VERSIONDSN} DSNval-${VERSION_DSNVAL_NEW}" >> $REP_CIBLE/${MODULE}-home/conf/com.soprahr.edsn.ui.webapp.cfg
		echo "ajout parametre altTitle dans le fichier com.soprahr.edsn.ui.webapp.cfg"
fi

        case `hostname` in
		frsopslappv21)
			CONNECT_STRING=`/hraccess9/exploitation/shell/getConnectString.sh`
		;;
		frsopslappv22)
			CONNECT_STRING=`/hraccess9/exploitation/shell/getConnectString.sh`
		;;
                frsopslappv25)
                        CONNECT_STRING=`$SIGACS/exploitation/batch/getConnectString.sh`
                ;;
                frsopslappv26)
                        CONNECT_STRING=`$SIGACS/exploitation/batch/getConnectString.sh`
                ;;
		*)
			CONNECT_STRING=`$INIT_PATH/shell/getConnectString.sh`
		;;
	esac
EDSN_CONNECT_STRING=${CONNECT_STRING}
#
if [ "x${APPLI_EDSN_USER}" = "xEDSN" ]
then
typeset -u L
typeset -l U
#U=${APPLI_EDSN_USER}
U=edsn
L=$LOGNAME
#EDSN_CONNECT_STRING=${APPLI_EDSN_USER}/$(psw ${APPLI_EDSN_HOST} $U $L)
EDSN_CONNECT_STRING=EDSNIFS/EDSNIFS
fi
export EDSN_CONNECT_STRING

#installation des kar et demarrage karaf
cd $REP_CIBLE/${MODULE}-home/work/addons
rm -f hraccess-feature-*
rm -f dsnval-feature-*
cp -f ${REP_CIBLE}/hraccess-feature-${VERSION_KAR}.kar $REP_CIBLE/${MODULE}-home/work/addons
cp -f ${REP_CIBLE}/dsnval-feature-${VERSION_DSNVAL_NEW}.kar $REP_CIBLE/${MODULE}-home/work/addons
chmod 775 *
echo "- demarrage $MODULE ${VERSION_NEW}"
cd ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/bin
echo "merci de patienter quelques minutes"
./start clean;./waitready
echo "fin attente demmarrage"
sleep 30
echo "debut addon-list"
./client "addon:list"
echo "fin addon:list"

# update tables differentiel
echo "- mise a jour des tables BDSN" 
cd  ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/ddl/update/oracle
	version_cible=$(echo "${VERSION_NEW}" | cut -c1,3)
	version_source=$(echo "${VERSION_OLD}" | cut -c1,3)
	ls -n edsn.oracle.update_* | awk '{print $NF}' | while read ficsqlupd
	do
		
		vsqlupd1=$(echo "${ficsqlupd}" | awk -F"_" '{print $2}' | cut -c1,3)
		vsqlupd2=$(echo "${ficsqlupd}" | awk -F"_" '{print $NF}' | cut -c1,3)
		if [ $vsqlupd1 -ge $version_source ] && [ $vsqlupd2 -le $version_cible ]
		then
			filenam_ficsqlupd=$(basename ${ficsqlupd} .sql)
			echo "execution de ${ficsqlupd}"
			cat ${ficsqlupd} | sqlplus $EDSN_CONNECT_STRING > $LOG/${filenam_ficsqlupd}.log
			tupdsql="1"
			echo "merci de consulter la log mise ajour oracle $LOG/${filenam_ficsqlupd}.log"
		fi
	done
        ls -n activiti.oracle.update_* | awk '{print $NF}' | while read activitisqlupd
        do
                vactivitisqlupd1=$(echo "${activitisqlupd}" | awk -F"_" '{print $2}' | cut -c1,3)
                vactivitisqlupd2=$(echo "${activitisqlupd}" | awk -F"_" '{print $NF}' | cut -c1,3)
                if [ $vactivitisqlupd1 -ge $version_source ] && [ $vactivitisqlupd2 -le $version_cible ]
                then
                        filenam_activitisqlupd=$(basename ${activitisqlupd} .sql)
                        echo "execution de ${activitisqlupd}"
                        cat ${activitisqlupd} | sqlplus $EDSN_CONNECT_STRING > $LOG/${filenam_activitisqlupd}.log
	        	tupdsql="1"
		        echo "merci de consulter la log mise a jour oracle $LOG/${filenam_activitisqlupd}.log"
                fi
        done
	ls -n async.oracle.update_* | awk '{print $NF}' | while read asyncsqlupd
	do
		vasyncsqlupd1=$(echo "${asyncsqlupd}" | awk -F"_" '{print $2}' | cut -c1,3)
		vasyncsqlupd2=$(echo "${asyncsqlupd}" | awk -F"_" '{print $NF}' | cut -c1,3)
		if [ $vasyncsqlupd1 -ge $version_source ] && [ $vasyncsqlupd2 -le $version_cible ]
		then
			filenam_asyncsqlupd=$(basename ${asyncsqlupd} .sql)
			echo "execution de ${asyncsqlupd}"
			cat ${asyncsqlupd} | sqlplus $EDSN_CONNECT_STRING > $LOG/${filenam_asyncsqlupd}.log
			tupdsql="1"
			echo "merci de consulter la log mise a jour oracle  $LOG/${filenam_asyncsqlupd}.log"
		fi
	done
        if [ $(echo "${VERSION_OLD}" | cut -c1) -eq 5 ] && [ $(echo "${VERSION_OLD}" | cut -c1,3,5) -lt 503 ] && [ $(echo "${VERSION_NEW}" | cut -c1,3,5) -gt 502 ]
	then
  	echo "drop et recreate index IXdsnHistoContrat"
        echo "drop index IXdsnHistoContrat;" > updt-IXdsnHistoContrat.sql
	echo "commit;" >> updt-IXdsnHistoContrat.sql
        echo "create index IXdsnHistoContrat on dsnHistoContrat (nir, dateDebutContrat, numeroContrat, periodeDsn) ;"  >> updt-IXdsnHistoContrat.sql
	echo "commit;"  >> updt-IXdsnHistoContrat.sql
        cat updt-IXdsnHistoContrat.sql | sqlplus $EDSN_CONNECT_STRING > $LOG/updt-IXdsnHistoContrat.log  
	echo "merci de consulter la log mise a jour oracle $LOG/updt-IXdsnHistoContrat.log"
	fi		
	if [ "${tupdsql}" = "" ]
	then
		echo "fin des updates de table"
	fi
 
# arr�t edsn et redemarrage pour prise en compte.
echo "- arret en cours"
cd ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/bin
./stop
sleep 5
attente=12
processus=$(ps -fu $(whoami) | grep java | grep -w Dedsn.home | grep -v grep | awk '{print $2}')
processus2=$(ps -fu $(whoami) | grep edsn | grep -w 'edsn server' | grep -v grep | awk '{print $2}')
if [ -n "$processus" ] || [ -n "$processus2" ]
then
  while [ -n "$processus" ] || [ -n "$processus2" ] && [ $attente -gt 0 ]
  do
    sleep 5
    echo "Attente de la fin du processus..."
    processus=$(ps -fu $(whoami) | grep java | grep -w Dedsn.home | grep -v grep | awk '{print $2}')
    processus2=$(ps -fu $(whoami) | grep edsn | grep -w 'edsn server' | grep -v grep | awk '{print $2}')
    (( attente = attente - 1 ))
  done

  if [ -n "$processus" ] || [ -n "$processus2" ]
  then
    echo "Le processus web sur $serveur_web tourne encore, je le kill!"
    kill -9 $processus $processus2
  fi
fi

if [ `hostname` = "frsopslapp058" ] || [ `hostname` = "frsopslapp057" ] || [ `hostname` = "frsopslapp065" ] || [ `hostname` = "frsopslapp066" ]
then
echo "recreation du lien du nouveau dsn install� ${REP_CIBLE}/${MODULE}-${VERSION_NEW}� vers  ${REP_CIBLE}/edsn"
        cd ${REP_CIBLE}
	rm -f edsn
	ln -s ${REP_CIBLE}/${MODULE}-${VERSION_NEW} edsn
fi
echo "- redemarrage en cours"
cd ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/bin
./start clean;./waitready

#sleep 300
echo "fin attente redemarrage"
cd ${REP_CIBLE}/${MODULE}-${VERSION_NEW}/bin
#./client "bundle:list"
nbBundleNOTOK=$(./client "bundle:list" | grep -v Active | tail -n +4 | wc -l)
if [ ${nbBundleNOTOK} = "0" ]
then
        echo "tous les services sont correctement demarr�s"
else
        echo "les services suivants ne sont pas correctement demarr�s:"
        ./client "bundle:list" | grep -v Active
fi

# mise a jour du profile_73 pour l alias dsnbin
echo "- mise a jour alias dsnbin du profile_73"
if [ `hostname` = "frsopslapp058" ] || [ `hostname` = "frsopslapp057" ] || [ `hostname` = "frsopslapp065" ] || [ `hostname` = "frsopslapp066" ]
then

    sed -i "s:alias dsnbin=.*:alias dsnbin='cd \$SIGACS/dsn/${MODULE}-${VERSION_NEW}/bin;ls -rtl':g" $HOME/.profile_73
    sed -i "s:EDSNCMD=.*:EDSNCMD=\$SIGACS/dsn/${MODULE}-${VERSION_NEW}/bin:g" $HOME/.profile_73
  else 


    sed -i "s:alias dsnbin=.*:alias dsnbin='cd \$SIGACS/EDSN/${MODULE}-${VERSION_NEW}/bin;ls -rtl':g" $HOME/.profile_73    
    sed -i "s:EDSNCMD=.*:EDSNCMD=\$SIGACS/EDSN/${MODULE}-${VERSION_NEW}/bin:g" $HOME/.profile_73
fi
# ajout alias dsnreloader
echo "- mise a jour alias rldbin et rldlog du profile_73"
  if [ `hostname` = "frsopslapp058" ] || [ `hostname` = "frsopslapp057" ] 
  then
        if [ $(grep -c rldbin $HOME/.profile_73) -eq 0 ]
        then
        echo "alias rldbin='cd \$SIGACS/dsn/hr-dsn-reloader-${VERSION_RLD_NEW}/bin;ls -rtl'" >> $HOME/.profile_73
        else
         sed -i "s:alias rldbin=.*:alias rldbin='cd \$SIGACS/dsn/hr-dsn-reloader-${VERSION_RLD_NEW}/bin;ls -rtl':g" $HOME/.profile_73
        fi
        if [ $(grep -c rldlog $HOME/.profile_73) -eq 0 ]
        then
        echo "alias rldlog='cd \$SIGACS/dsn/hr-dsn-reloader-${VERSION_RLD_NEW}/logs;ls -rtl'" >> $HOME/.profile_73
        else
         sed -i "s:alias rldlog=.*:alias rldlog='cd \$SIGACS/dsn/hr-dsn-reloader-${VERSION_RLD_NEW}/logs;ls -rtl':g" $HOME/.profile_73
        fi
  else 

        if [ $(grep -c rldbin $HOME/.profile_73) -eq 0 ]
        then
        echo "alias rldbin='cd \$SIGACS/EDSN/hr-dsn-reloader-${VERSION_RLD_NEW}/bin;ls -rtl'" >> $HOME/.profile_73
        else
         sed -i "s:alias rldbin=.*:alias rldbin='cd \$SIGACS/EDSN/hr-dsn-reloader-${VERSION_RLD_NEW}/bin;ls -rtl':g" $HOME/.profile_73
        fi
        if [ $(grep -c rldlog $HOME/.profile_73) -eq 0 ]
        then
        echo "alias rldlog='cd \$SIGACS/EDSN/hr-dsn-reloader-${VERSION_RLD_NEW}/logs;ls -rtl'" >> $HOME/.profile_73
        else
         sed -i "s:alias rldlog=.*:alias rldlog='cd \$SIGACS/EDSN/hr-dsn-reloader-${VERSION_RLD_NEW}/logs;ls -rtl':g" $HOME/.profile_73
        fi
  fi

# 2 Installation nouvelle version hr-dsn-reloader-x.y.z-dir.zip
# je cree le rep $SIGACS/EDSN/hr-dsn-reloader-x.y.z 
# je recupere du depot sous /admin/depot/DSN le produit et le copie dans repertoire $SIGACS/EDSN/hr-dsn-reloader-x.y.z
# je dezzipe le module hr-dsn-reloader-x.y.z-dir.zip
echo "7 - Installation Reloader ${VERSION_RLD_NEW}"
if [ -e "${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}" ]
	then
		echo "La Version ${VERSION_RLD_NEW} est deja installe"
	else
		cd ${REP_CIBLE}
		mkdir hr-dsn-reloader-${VERSION_RLD_NEW}
		cp -f ${REP_DEPOT}/HRA-${VERSIONDSN}/hr-dsn-reloader-${VERSION_RLD_NEW}-dir.zip ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}
		cd ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}
		unzip -qq hr-dsn-reloader-${VERSION_RLD_NEW}-dir.zip
# je supprime les *.cmd et *.bat du bin = inutile
# je donne les droits d exection dans le bin
# je place le connector jdbc oracle du serveur dans lib
		cd ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/bin
	sed -e '2a\export JAVA_HOME=\/etc\/alternatives\/jre_1.8.0' setenv.sh > setenvtemp.sh | chmod 775 setenvtemp.sh | find setenvtemp.sh -exec mv {} setenv.sh \;
		rm -f *.cmd
		chmod 775 *
		cp -f $REP_CIBLE/${MODULE}-home/work/addons/ojdbc* ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/lib
		# on regenere le fichier jdbc.properties
		. call_zcn
		URLJDBC="$(tnsping $ORACLE_SID | grep "DESCRIPTION " | awk -F"Attempting to contact " '{print $2}')"
		echo > ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo "#database properties" >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo " " >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo "#To define, example : oracle.jdbc.OracleDriver" >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo "jdbc.driverClassName=oracle.jdbc.driver.OracleDriver" >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo " " >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo "#To define" >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo "jdbc.url=jdbc:oracle:thin:@$URLJDBC" >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo " " >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo "#To define" >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo "jdbc.username=${HRUSER}" >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo " " >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo "#To define" >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo "jdbc.password=${HRPSWD}" >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo " " >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo "#Default schema HR" >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties
		echo "jdbc.tablePrefix=HR" >> ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties

		echo "fichier ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/jdbc.properties mis a jour"
		export envmps=$(echo "${CDPLPH}" | cut -c1-5)
		if [ "$Slice" = "58" ] || [ "$Slice" = "59" ] || [ "$envmps" = "CHAV5" ]
			then
			sed -i "s:presence.pgpdos=.*:presence.pgpdos=0:g" ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/dsn.properties
			echo "-mise a jour pgpdos=0 pour les V5 dans ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW}/conf/dsn.properties"
		fi
		if [ `hostname` = "frsopslapp058" ] || [ `hostname` = "frsopslapp057" ] || [ `hostname` = "frsopslapp065" ] || [ `hostname` = "frsopslapp066" ]
			then
			echo "recreation du lien du nouveau reloader installe ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW} vers  ${REP_CIBLE}/dsn-reloader"
			cd ${REP_CIBLE}
			rm -f dsn-reloader
			ln -s ${REP_CIBLE}/hr-dsn-reloader-${VERSION_RLD_NEW} dsn-reloader
		fi
fi

#suppression des repertoires a l' exception de ceux en vigueur
echo "- suppression des anciens modules"
find . -type d -name '${MODULE}-1*' ! -name '${MODULE}-${VERSION_NEW}' -exec rm -Rf {} \;
find . -type d -name '${MODULE}-2*' ! -name '${MODULE}-${VERSION_NEW}' -exec rm -Rf {} \;
find . -type d -name '${MODULE}-3*' ! -name '${MODULE}-${VERSION_NEW}' -exec rm -Rf {} \;
find . -type d -name '${MODULE}-4*' ! -name '${MODULE}-${VERSION_NEW}' -exec rm -Rf {} \;
find . -type d -name '${MODULE}-5*' ! -name '${MODULE}-${VERSION_NEW}' -exec rm -Rf {} \;
rm -f ${REP_CIBLE}/*.tar.gz
rm -f ${REP_CIBLE}/*.kar
echo "FIN DU SCRIPT"
exit 0


