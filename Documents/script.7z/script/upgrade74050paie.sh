#!/bin/ksh
#===============================================================================
#
#  FICHIER: upgradeHRATOOLS7405002.sh
#  DESCRIPTION: Installation Tools HRA 74050 ML2
#  VERSION: 1.0
#  OPTIONS: ---
#  EXIGENCES: ---
#  AUTEUR: KRAIEM AlaEddine
#  DATE DE CREATION: 14/04/2021
#	Modification : 03/06/2021 AlaEddine ==> ajout HF 01
#===============================================================================

#======================= Initialisation ========================================
VERSION=7.40.05002.0000
DEPOT=/admin/depot/esp/esp1.5/${VERSION}/                                    #Depot des Tools HRA
HF=/admin/depot/hotfixes/${VERSION}                                          #Depot des hotfixes
RACINE_LOG=/admin/bin/runtools/logs/                                         #Depot des LOGS
mkdir -p $RACINE_LOG
LOGFILE=${RACINE_LOG}/CR_upgrade_`whoami`_${VERSION}_`date +%Y%m%d`.log      #Fichier LOG principale
LOGFILE_BETA=${RACINE_LOG}/CR_MOVE_`whoami`_${VERSION}_`date +%Y%m%d`.log    #Fichier LOG en mode verbose pour plus des d�tailles
#===============================================================================

SNAP_PROCESS () {
echo "*-------------------- STEP_N1 ------------------------------------*" >> ${LOGFILE}
echo "* Chargement de .profile est prise image des services avant arr�t *" >> ${LOGFILE}
echo "*-----------------------------------------------------------------*" >> ${LOGFILE}
echo " \n" >>${LOGFILE}
ps -fu `whoami` >> ${LOGFILE}
}

STOP_SERVICES () {
echo "*-------------------- STEP_N2 ------------------------------------*" >> ${LOGFILE}
echo "*                 Arr�t des services                              *" >> ${LOGFILE}
echo "*-----------------------------------------------------------------*" >> ${LOGFILE}

APROCESS=""
APROCESS=`ps -fu $LOGNAME | grep -v "grep" | grep AP0`
if [ "${APROCESS}" != "" ]
then
  csadmin stop cs
  if [ $? -ne 0 ]
  then
      echo "`date +%Y%m%d-%H:%M` :csdamin stop cs -----> KO" >> ${LOGFILE}
  else
      echo "`date +%Y%m%d-%H:%M` :csdamin stop cs -----> OK" >> ${LOGFILE}
      kill -9 $(echo $APROCESS | awk '{print $2}')
  fi
fi

APROCESS=""
APROCESS=`ps -fu $LOGNAME | grep -v "grep" | grep openhr/bin/bootstrap.jar`
if [ "${APROCESS}" != "" ]
then
  csadmin stop openhr
  if [ $? -ne 0 ]
  then
      echo "`date +%Y%m%d-%H:%M` :csdamin stop openhr -----> KO" >> ${LOGFILE}
  else
      echo "`date +%Y%m%d-%H:%M` :csdamin stop openhr -----> OK" >> ${LOGFILE}
      kill -9 $(echo $APROCESS | awk '{print $2}')
  fi
fi
APROCESS=""
APROCESS=`ps -fu $LOGNAME | grep -v "grep" | grep openhr2/bin/bootstrap.jar`
if [ "${APROCESS}" != "" ]
then
  csadmin stop openhr2
  if [ $? -ne 0 ]
  then
      echo "`date +%Y%m%d-%H:%M` :csdamin stop openhr2 -----> KO" >> ${LOGFILE}
  else
      echo "`date +%Y%m%d-%H:%M` :csdamin stop openhr2 -----> OK" >> ${LOGFILE}
      kill -9 $(echo $APROCESS | awk '{print $2}')
  fi
fi
APROCESS=""
APROCESS=`ps -fu $LOGNAME | grep -v "grep" | grep openhr3/bin/bootstrap.jar`
if [ "${APROCESS}" != "" ]
then
  csadmin stop openhr3
  if [ $? -ne 0 ]
  then
      echo "`date +%Y%m%d-%H:%M` :csdamin stop openhr3 -----> KO" >> ${LOGFILE}
  else
      echo "`date +%Y%m%d-%H:%M` :csdamin stop openhr3 -----> OK" >> ${LOGFILE}
      kill -9 $(echo $APROCESS | awk '{print $2}')
  fi
fi

APROCESS=""
APROCESS=`ps -fu $LOGNAME | grep -v "grep" | grep tomtools/bin/bootstrap.jar`
if [ "${APROCESS}" != "" ]
then
  cd ~/tomtools/bin
  ./shutdown.sh
  if [ $? -ne 0 ]
  then
      echo "`date +%Y%m%d-%H:%M` :stop_tomtools -----> KO" >> ${LOGFILE}
  else
      echo "`date +%Y%m%d-%H:%M` :stop_tomtools  -----> OK" >> ${LOGFILE}
      kill -9 $(echo $APROCESS | awk '{print $2}') 
  fi
fi

APROCESS=""
APROCESS=`ps -fu $LOGNAME | grep -v "grep" | grep tomweb/bin/bootstrap.jar`
if [ "${APROCESS}" != "" ]
then
  cd ~/tomweb/bin
  ./shutdown.sh
  if [ $? -ne 0 ]
  then
      echo "`date +%Y%m%d-%H:%M` :stop_tomweb -----> KO" >> ${LOGFILE} 
  else
      echo "`date +%Y%m%d-%H:%M` :stop_tomweb -----> OK" >> ${LOGFILE}
      kill -9 $(echo $APROCESS | awk '{print $2}')
  fi
fi
APROCESS=""
APROCESS=`ps -fu $LOGNAME | grep -v "grep" | grep tomweb2/bin/bootstrap.jar`
if [ "${APROCESS}" != "" ]
then
  cd ~/tomweb2/bin
  ./shutdown.sh
  if [ $? -ne 0 ]
  then
      echo "`date +%Y%m%d-%H:%M` :stop_tomweb2 -----> KO" >> ${LOGFILE}
  else
      echo "`date +%Y%m%d-%H:%M` :stop_tomweb2 -----> OK" >> ${LOGFILE}
      kill -9 $(echo $APROCESS | awk '{print $2}')
  fi
fi
APROCESS=""
APROCESS=`ps -fu $LOGNAME | grep -v "grep" | grep tomweb3/bin/bootstrap.jar`
if [ "${APROCESS}" != "" ]
then
  cd ~/tomweb3/bin
  ./shutdown.sh
  if [ $? -ne 0 ]
  then
      echo "`date +%Y%m%d-%H:%M` :stop_tomweb3 -----> KO" >> ${LOGFILE}
  else
      echo "`date +%Y%m%d-%H:%M` :stop_tomweb3 -----> OK" >> ${LOGFILE}
      kill -9 $(echo $APROCESS | awk '{print $2}')
  fi
fi
}

SAVE_SERVICES () {
echo "*-------------------- STEP_N3 ------------------------------------*" >> ${LOGFILE}
echo "*                 Lancement des sauvegardes                       *" >> ${LOGFILE}
echo "*-----------------------------------------------------------------*" >> ${LOGFILE}

cd $SIGACS
tar -czvf openhr.tar.gz openhr >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
  then 
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/openhr -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/openhr -----> OK" >> ${LOGFILE}
    mv --verbose openhr.tar.gz $SIGACS/backup/openhr_`date +%Y%m%d-%H%M`.tar.gz >> ${LOGFILE_BETA}
    if [ $? -ne 0 ]
      then 
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/openhr.tar.gz vers $SIGACS/backup/openhr_`date +%Y%m%d-%H%M`.tar.gz-----> KO" >> ${LOGFILE}
      else
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/openhr.tar.gz vers $SIGACS/backup/openhr_`date +%Y%m%d-%H%M`.tar.gz -----> OK" >> ${LOGFILE}
    fi  
fi
tar -czvf openhr2.tar.gz openhr2 >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/openhr2 -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/openhr2 -----> OK" >> ${LOGFILE}
    mv --verbose openhr2.tar.gz $SIGACS/backup/openhr2_`date +%Y%m%d-%H%M`.tar.gz >> ${LOGFILE_BETA}
    if [ $? -ne 0 ]
      then
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/openhr2.tar.gz vers $SIGACS/backup/openhr2_`date +%Y%m%d-%H%M`.tar.gz-----> KO" >> ${LOGFILE}
      else
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/openhr2.tar.gz vers $SIGACS/backup/openhr2_`date +%Y%m%d-%H%M`.tar.gz -----> OK" >> ${LOGFILE}
    fi
fi
tar -czvf openhr3.tar.gz openhr3 >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/openhr3 -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/openhr3 -----> OK" >> ${LOGFILE}
    mv --verbose openhr3.tar.gz $SIGACS/backup/openhr3_`date +%Y%m%d-%H%M`.tar.gz >> ${LOGFILE_BETA}
    if [ $? -ne 0 ]
      then
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/openhr3.tar.gz vers $SIGACS/backup/openhr3_`date +%Y%m%d-%H%M`.tar.gz-----> KO" >> ${LOGFILE}
      else
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/openhr3.tar.gz vers $SIGACS/backup/openhr3_`date +%Y%m%d-%H%M`.tar.gz -----> OK" >> ${LOGFILE}
    fi
fi
#----------------------------------------------------
tar -czvf tomweb.tar.gz tomweb >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
  then 
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/tomweb -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/tomweb -----> OK" >> ${LOGFILE}
    mv --verbose tomweb.tar.gz $SIGACS/backup/tomweb_`date +%Y%m%d-%H%M`.tar.gz >> ${LOGFILE_BETA}
    if [ $? -ne 0 ]
      then 
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/tomweb.tar.gz vers $SIGACS/backup/tomweb_`date +%Y%m%d-%H%M`.tar.gz-----> KO" >> ${LOGFILE}
      else
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/tomweb.tar.gz vers $SIGACS/backup/tomweb_`date +%Y%m%d-%H%M`.tar.gz -----> OK" >> ${LOGFILE}
    fi  
fi
tar -czvf tomweb2.tar.gz tomweb2 >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/tomweb2 -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/tomweb2 -----> OK" >> ${LOGFILE}
    mv --verbose tomweb2.tar.gz $SIGACS/backup/tomweb2_`date +%Y%m%d-%H%M`.tar.gz >> ${LOGFILE_BETA}
    if [ $? -ne 0 ]
      then
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/tomweb2.tar.gz vers $SIGACS/backup/tomweb2_`date +%Y%m%d-%H%M`.tar.gz-----> KO" >> ${LOGFILE}
      else
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/tomweb2.tar.gz vers $SIGACS/backup/tomweb2_`date +%Y%m%d-%H%M`.tar.gz -----> OK" >> ${LOGFILE}
    fi
fi
tar -czvf tomweb3.tar.gz tomweb3 >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/tomweb3 -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/tomweb3 -----> OK" >> ${LOGFILE}
    mv --verbose tomweb3.tar.gz $SIGACS/backup/tomweb3_`date +%Y%m%d-%H%M`.tar.gz >> ${LOGFILE_BETA}
    if [ $? -ne 0 ]
      then
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/tomweb3.tar.gz vers $SIGACS/backup/tomweb3_`date +%Y%m%d-%H%M`.tar.gz-----> KO" >> ${LOGFILE}
      else
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/tomweb3.tar.gz vers $SIGACS/backup/tomweb3_`date +%Y%m%d-%H%M`.tar.gz -----> OK" >> ${LOGFILE}
    fi
fi
#----------------------------------------------------
tar -czvf tomtools.tar.gz tomtools >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
  then 
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/tomtools -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Compression $SIGACS/tomtools -----> OK" >> ${LOGFILE}
    mv --verbose tomtools.tar.gz $SIGACS/backup/tomtools_`date +%Y%m%d-%H%M`.tar.gz >> ${LOGFILE_BETA}
    if [ $? -ne 0 ]
      then 
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/tomtools.tar.gz vers $SIGACS/backup/tomtools_`date +%Y%m%d-%H%M`.tar.gz-----> KO" >> ${LOGFILE}
      else
        echo "`date +%Y%m%d-%H:%M` :Deplassement $SIGACS/tomtools.tar.gz vers $SIGACS/backup/tomtools_`date +%Y%m%d-%H%M`.tar.gz -----> OK" >> ${LOGFILE}
    fi  
fi
#----------------------------------------------------
}

Install_Openhr () {
echo "*-------------------- STEP_N4-------------------------------------*" >> ${LOGFILE}
echo "*           Installation OPENHR ${VERSION}                   *" >> ${LOGFILE}
echo "*-----------------------------------------------------------------*" >> ${LOGFILE}
cd ~/
if [ ! -d "~/openhr-avant74050" ]
then
  cp -vpR ~/openhr ~/openhr-avant74050 >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr vers $SIGACS/openhr-avant74050 -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr vers $SIGACS/openhr-avant74050 -----> OK" >> ${LOGFILE}
  fi
else
  echo "Copy Openhr KO , sortie du script"
  exit 0
fi
rm -rvf $SIGACS/openhr >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/openhr -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/openhr -----> OK" >> ${LOGFILE}
fi
cp -vR /admin/depot/esp/esp1.5/7.40.05002.0000/openhr-server $SIGACS/openhr >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/openhr-server $SIGACS/openhr -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy/admin/depot/esp/esp1.5/7.40.05002.0000/openhr-server $SIGACS/openhr -----> OK" >> ${LOGFILE}
fi
cp -v $SIGACS/openhr-avant74050/conf/*.properties  $SIGACS/openhr/conf >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/conf/*.properties  $SIGACS/openhr/conf -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/conf/*.properties  $SIGACS/openhr/conf -----> OK" >> ${LOGFILE}
fi
cp -v $SIGACS/openhr-avant74050/bin/*.sh  $SIGACS/openhr/bin >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/bin/*.sh  $SIGACS/openhr/bin -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/bin/*.sh  $SIGACS/openhr/bin -----> OK" >> ${LOGFILE}
fi
cp -v $SIGACS/OpenDS-1.0.0/lib/OpenDS.jar $SIGACS/openhr/lib >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/OpenDS-1.0.0/lib/OpenDS.jar $SIGACS/openhr/lib -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/OpenDS-1.0.0/lib/OpenDS.jar $SIGACS/openhr/lib -----> OK" >> ${LOGFILE}
fi
cp -v /admin/depot/esp/esp1.5/7.40.05002.0000/ldap/hr-user-account-management-api.jar $SIGACS/openhr/lib >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
	echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/ldap/hr-user-account-management-api.jar $SIGACS/openhr/lib -----> KO" >> ${LOGFILE}
else
	echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/ldap/hr-user-account-management-api.jar $SIGACS/openhr/lib -----> OK" >> ${LOGFILE}
fi
cp -v /admin/depot/esp/esp1.5/7.40.05002.0000/ldap/hr-user-account-management-server.jar $SIGACS/openhr/lib >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
	echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/ldap/hr-user-account-management-server.jar $SIGACS/openhr/lib -----> KO" >> ${LOGFILE}
else
	echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/ldap/hr-user-account-management-server.jar $SIGACS/openhr/lib -----> OK" >> ${LOGFILE}
fi
cp -vp /admin/bin/runtools/Crowdopenhrjar/*.jar $SIGACS/openhr/lib >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
	echo "`date +%Y%m%d-%H:%M` :Copy /admin/bin/runtools/Crowdopenhrjar/*.jar $SIGACS/openhr/lib -----> KO" >> ${LOGFILE}
else
	echo "`date +%Y%m%d-%H:%M` :Copy /admin/bin/runtools/Crowdopenhrjar/*.jar $SIGACS/openhr/lib -----> OK" >> ${LOGFILE}
fi
cp -vp /admin/bin/runtools/Crowdopenhrjar/truststore_ad $SIGACS/openhr/conf >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
	echo "`date +%Y%m%d-%H:%M` :Copy /admin/bin/runtools/Crowdopenhrjar/truststore_ad $SIGACS/openhr/conf -----> KO" >> ${LOGFILE}
else
    echo "`date +%Y%m%d-%H:%M` :Copy /admin/bin/runtools/Crowdopenhrjar/truststore_ad $SIGACS/openhr/conf -----> OK" >> ${LOGFILE}
fi
rm -fv $SIGACS/openhr/conf/security.xml >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
	echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/openhr/conf/security.xml -----> KO" >> ${LOGFILE}
else
	echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/openhr/conf/security.xml -----> OK" >> ${LOGFILE}
fi
rm -fv $SIGACS/openhr/conf/services.xml >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
	echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/openhr/conf/services.xml -----> KO" >> ${LOGFILE}
else
    echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/openhr/conf/services.xml -----> OK" >> ${LOGFILE}
fi
cp -vp $SIGACS/openhr-avant74050/conf/services.xml $SIGACS/openhr/conf/ >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
	echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/conf/services.xml $SIGACS/openhr/conf/ -----> KO" >> ${LOGFILE}
else
	echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/conf/services.xml $SIGACS/openhr/conf/ -----> OK" >> ${LOGFILE}
fi
cp -vp $SIGACS/openhr-avant74050/conf/security.xml $SIGACS/openhr/conf/ >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
	echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/conf/security.xml $SIGACS/openhr/conf/ -----> KO" >> ${LOGFILE}
else
	echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/conf/security.xml $SIGACS/openhr/conf/ -----> OK" >> ${LOGFILE}
fi
if [ -d "$SIGACS/OpenDS-1.0.0" ]
then
	ln -s $SIGACS/OpenDS-1.0.0/config/truststore $SIGACS/openhr/conf/truststore
	if [ $? -ne 0 ]
	then
	   echo "`date +%Y%m%d-%H:%M` :ln -s $SIGACS/OpenDS-1.0.0/config/truststore $SIGACS/openhr/conf/truststore -----> KO" >> ${LOGFILE}
	else
	   echo "`date +%Y%m%d-%H:%M` :ln -s $SIGACS/OpenDS-1.0.0/config/truststore $SIGACS/openhr/conf/truststore -----> OK" >> ${LOGFILE}
	fi
fi
if [ -d "$SIGACS/OpenDS-2.3.0" ]
then
	ln -s $SIGACS/OpenDS-2.3.0/config/truststore $SIGACS/openhr/conf/truststore
	if [ $? -ne 0 ]
	then
	   echo "`date +%Y%m%d-%H:%M` :ln -s $SIGACS/OpenDS-2.3.0/config/truststore $SIGACS/openhr/conf/truststore -----> KO" >> ${LOGFILE}
	else
	   echo "`date +%Y%m%d-%H:%M` :ln -s $SIGACS/OpenDS-2.3.0/config/truststore $SIGACS/openhr/conf/truststore -----> OK" >> ${LOGFILE}
	fi
fi
rm -fv $SIGACS/openhr/bin/*.cmd >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
	echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/openhr/bin/*.cmd -----> KO" >> ${LOGFILE}
else
	echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/openhr/bin/*.cmd -----> OK" >> ${LOGFILE}
fi
###########################################################
#On declare SSO openhr dans cette partie

echo "`date +%Y%m%d-%H:%M` :Report sso openhr "  >> ${LOGFILE}
cp -vp $SIGACS/openhr-avant74050/lib/sso* $SIGACS/openhr/lib/ >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/sso* $SIGACS/openhr/lib/ -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/sso* $SIGACS/openhr/lib/ -----> OK" >> ${LOGFILE}
fi
###########################################################
}

Install_Tomweb () {

echo "*-------------------- STEP_N5-------------------------------------*" >> ${LOGFILE}
echo "*           Installation HRAWEB ${VERSION}                   *" >> ${LOGFILE}
echo "*-----------------------------------------------------------------*" >> ${LOGFILE}
cd ~/
if [ ! -d "~/tomweb-avant74050" ]
then
  cp -vpR ~/tomweb ~/tomweb-avant74050 >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb vers $SIGACS/tomweb-avant74050 -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb vers $SIGACS/tomweb-avant74050 -----> OK" >> ${LOGFILE}
  fi
else
  echo "Copy tomweb KO , sortie du script"
  exit 0
fi
#------------------------------------------------------------------------------------------------------------
cp -v /admin/depot/esp/esp1.5/7.40.05002.0000/hra-space/web.tar.gz  $SIGACS/tomweb/webapps >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/hra-space/web.tar.gz  $SIGACS/tomweb/webapps -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/hra-space/web.tar.gz  $SIGACS/tomweb/webapps -----> OK" >> ${LOGFILE}
fi
rm -Rfv $SIGACS/tomweb/webapps/hra-space >>  ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hra-space -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hra-space -----> OK" >> ${LOGFILE}
fi
rm -Rfv $SIGACS/tomweb/webapps/hr-dms >>  ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-dms -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-dms -----> OK" >> ${LOGFILE}
fi
rm -Rfv $SIGACS/tomweb/webapps/hr-portlets >>  ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-portlets -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-portlets -----> OK" >> ${LOGFILE}
fi
rm -Rfv $SIGACS/tomweb/webapps/hr-rich-client >>  ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-rich-client -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-rich-client -----> OK" >> ${LOGFILE}
fi
rm -Rfv $SIGACS/tomweb/webapps/hr-self-service >>  ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-self-service -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-self-service -----> OK" >> ${LOGFILE}
fi
rm -Rfv $SIGACS/tomweb/webapps/hr-configuration-tool-web-smartgwt >>  ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-configuration-tool-web-smartgwt -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-configuration-tool-web-smartgwt -----> OK" >> ${LOGFILE}
fi
rm -fv  $SIGACS/tomweb/webapps/hr-configuration-tool-web-smartgwt.war >>  ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-configuration-tool-web-smartgwt.war -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-configuration-tool-web-smartgwt.war -----> OK" >> ${LOGFILE}
fi
rm -Rfv $SIGACS/tomweb/webapps/hr-configuration-tool-web >>  ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-configuration-tool-web -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-configuration-tool-web -----> OK" >> ${LOGFILE}
fi
#-------------------------------------------------------------------------------------------------------------
cp -v /admin/depot/HRCTv2/hr-configuration-tool-web-smartgwt-2.7.4.war $SIGACS/tomweb/webapps/hr-configuration-tool-web-smartgwt.war >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/HRCTv2/hr-configuration-tool-web-smartgwt-2.7.4.war $SIGACS/tomweb/webapps/hr-configuration-tool-web-smartgwt.war -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/HRCTv2/hr-configuration-tool-web-smartgwt-2.7.4.war $SIGACS/tomweb/webapps/hr-configuration-tool-web-smartgwt.war -----> OK" >> ${LOGFILE}
fi

cd $SIGACS/tomweb/webapps
tar -xzf web.tar.gz
rm -fv $SIGACS/tomweb/webapps/web.tar.gz >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/web.tar.gz -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/web.tar.gz -----> OK" >> ${LOGFILE}
fi
rm -fv $SIGACS/tomweb/shared/lib/* >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/shared/lib/* -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/shared/lib/* -----> OK" >> ${LOGFILE}
fi
cp -v /admin/depot/esp/esp1.5/7.40.05002.0000/shared-libs/* $SIGACS/tomweb/shared/lib >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/shared-libs/* $SIGACS/tomweb/shared/lib -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/shared-libs/* $SIGACS/tomweb/shared/lib -----> OK" >> ${LOGFILE}
fi
cp -Rv $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/conf/* $SIGACS/tomweb/webapps/hra-space/WEB-INF/conf >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/conf/* $SIGACS/tomweb/webapps/hra-space/WEB-INF/conf -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/conf/* $SIGACS/tomweb/webapps/hra-space/WEB-INF/conf -----> OK" >> ${LOGFILE}
fi
cp -fv $SIGACS/tomweb-avant74050/webapps/hr-dms/WEB-INF/conf/*.properties $SIGACS/tomweb/webapps/hr-dms/WEB-INF/conf >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-dms/WEB-INF/conf/*.properties $SIGACS/tomweb/webapps/hr-dms/WEB-INF/conf -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-dms/WEB-INF/conf/*.properties $SIGACS/tomweb/webapps/hr-dms/WEB-INF/conf -----> OK" >> ${LOGFILE}
fi
cp -v $SIGACS/tomweb-avant74050/webapps/hr-portlets/WEB-INF/conf/*.properties $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/conf >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-portlets/WEB-INF/conf/*.properties $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/conf -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-portlets/WEB-INF/conf/*.properties $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/conf -----> OK" >> ${LOGFILE}
fi
cp -v $SIGACS/tomweb-avant74050/webapps/hr-rich-client/WEB-INF/conf/*.properties $SIGACS/tomweb/webapps/hr-rich-client/WEB-INF/conf >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-rich-client/WEB-INF/conf/*.properties $SIGACS/tomweb/webapps/hr-rich-client/WEB-INF/conf -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-rich-client/WEB-INF/conf/*.properties $SIGACS/tomweb/webapps/hr-rich-client/WEB-INF/conf -----> OK" >> ${LOGFILE}
fi
cp -vf $SIGACS/tomweb-avant74050/webapps/hr-rich-client/WEB-INF/options.xml $SIGACS/tomweb/webapps/hr-rich-client/WEB-INF/  >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-rich-client/WEB-INF/options.xml $SIGACS/tomweb/webapps/hr-rich-client/WEB-INF/ -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-rich-client/WEB-INF/options.xml $SIGACS/tomweb/webapps/hr-rich-client/WEB-INF/ -----> OK" >> ${LOGFILE}
fi
cp -v $SIGACS/tomweb-avant74050/webapps/hr-self-service/WEB-INF/conf/*.properties $SIGACS/tomweb/webapps/hr-self-service/WEB-INF/conf >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-self-service/WEB-INF/conf/*.properties $SIGACS/tomweb/webapps/hr-self-service/WEB-INF/conf -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-self-service/WEB-INF/conf/*.properties $SIGACS/tomweb/webapps/hr-self-service/WEB-INF/conf -----> OK" >> ${LOGFILE}
fi

#verification presence hr-audit-console
if [ -d "$SIGACS/tomweb-avant74050/webapps/hr-audit-console" ]
then
  rm -vRf  $SIGACS/tomweb/webapps/hr-audit-console* >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then 
    echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-audit-console -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-audit-console -----> OK" >> ${LOGFILE}
  fi  
  cp -v /admin/depot/esp/esp1.5/7.40.05002.0000/audit-console/hr-audit-console.tar.gz $SIGACS/tomweb/webapps >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then 
    echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/audit-console/hr-audit-console.tar.gz $SIGACS/tomweb/webapps -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/audit-console/hr-audit-console.tar.gz $SIGACS/tomweb/webapps -----> OK" >> ${LOGFILE}
  fi  
  cd $SIGACS/tomweb/webapps
  tar -xzf hr-audit-console.tar.gz
  if [ $? -ne 0 ]
  then 
    echo "`date +%Y%m%d-%H:%M` :Decompression $SIGACS/tomweb/webapps/hr-audit-console.tar.gz -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Decompression $SIGACS/tomweb/webapps/hr-audit-console.tar.gz -----> OK" >> ${LOGFILE}
  fi
  rm hr-audit-console.tar.gz
else
  echo "Pas de hr-audit-console" >> ${LOGFILE}     
fi

#verification presence hr-ws
if [ -d "$SIGACS/tomweb-avant74050/webapps/hr-ws" ]
then
  rm -vRf $SIGACS/tomweb/webapps/hr-ws >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then 
    echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-ws -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-ws -----> OK" >> ${LOGFILE}
  fi   
  cp -v /admin/depot/esp/esp1.5/7.40.05002.0000/ws/hr-ws.tar.gz $SIGACS/tomweb/webapps >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then 
    echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/ws/hr-ws.tar.gz $SIGACS/tomweb/webapps -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/ws/hr-ws.tar.gz $SIGACS/tomweb/webapps -----> OK" >> ${LOGFILE}
  fi        
  cd $SIGACS/tomweb/webapps
  tar -xzf hr-ws.tar.gz
  if [ $? -ne 0 ]
  then 
    echo "`date +%Y%m%d-%H:%M` :Decompression $SIGACS/tomweb/webapps/hr-ws.tar.gz -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Decompression $SIGACS/tomweb/webapps/hr-ws.tar.gz -----> OK" >> ${LOGFILE}
  fi     
  cp -v $SIGACS/tomweb-avant74050/webapps/hr-ws/WEB-INF/conf/openhr.properties $SIGACS/tomweb/webapps/hr-ws/WEB-INF/conf >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then 
    echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-ws/WEB-INF/conf/openhr.properties $SIGACS/tomweb/webapps/hr-ws/WEB-INF/conf -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-ws/WEB-INF/conf/openhr.properties $SIGACS/tomweb/webapps/hr-ws/WEB-INF/conf -----> OK" >> ${LOGFILE}
  fi   
else
  echo "Pas de hr-ws" >> ${LOGFILE}
fi
if [ -d "$SIGACS/tomweb-avant74050/webapps/hr-gta-planning-web" ]
then
  rm -vRf $SIGACS/tomweb/webapps/hr-gta-planning-web* >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-gta-planning-web -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-gta-planning-web -----> OK" >> ${LOGFILE}
  fi
  rm -f $SIGACS/tomweb/webapps/hr-gta-planning-web.war*
  cp -v /admin/depot/esp/esp1.5/7.40.05002.0000/hr-gta-planning-web/hr-gta-planning-web-1.6.0.war $SIGACS/tomweb/webapps/hr-gta-planning-web.war >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/hr-gta-planning-web/hr-gta-planning-web-1.6.0.war $SIGACS/tomweb/webapps/hr-gta-planning-web.war -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/hr-gta-planning-web/hr-gta-planning-web-1.6.0.war $SIGACS/tomweb/webapps/hr-gta-planning-web.war -----> OK" >> ${LOGFILE}
  fi
else
  echo "Pas de hr-gta-planning-web" >> ${LOGFILE}
fi

if [ -d "$SIGACS/tomweb-avant74050/webapps/hr-trace-route" ]
then
  rm -vRf $SIGACS/tomweb/webapps/hr-trace-route >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-trace-route -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/hr-trace-route -----> OK" >> ${LOGFILE}
  fi
  rm -f $SIGACS/tomweb/webapps/hr-trace-route.war
  cp -v /admin/depot/esp/esp1.5/7.40.05002.0000/hr-trace-route/hr-trace-route.war $SIGACS/tomweb/webapps/ >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/hr-trace-route/hr-trace-route.war $SIGACS/tomweb/webapps/ -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/hr-trace-route/hr-trace-route.war $SIGACS/tomweb/webapps/ -----> OK" >> ${LOGFILE}
  fi
else
  echo "Pas de hr-gta-planning-web" >> ${LOGFILE}
fi

if [ -d "$SIGACS/tomweb-avant74050/webapps/ta-projects" ]
then
  rm -vRf $SIGACS/tomweb/webapps/ta-projects* >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/ta-projects -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomweb/webapps/ta-projects -----> OK" >> ${LOGFILE}
  fi
  rm -f $SIGACS/tomweb/webapps/ta-projects.war*
  cp -v /admin/depot/esp/esp1.5/7.40.05002.0000/ta-projects/ta-projects-2.0.11.war $SIGACS/tomweb/webapps/ta-projects.war >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/ta-projects/ta-projects-2.0.11.war $SIGACS/tomweb/webapps/ta-projects.war -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/ta-projects/ta-projects-2.0.11.war $SIGACS/tomweb/webapps/ta-projects.war -----> OK" >> ${LOGFILE}
  fi
else
  echo "Pas de hr-gta-planning-web" >> ${LOGFILE}
fi
###########################################################
# On declare ici les spec tomweb
###########################################################
cp -vp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp_std >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp_std -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp_std -----> OK" >> ${LOGFILE}
fi
cp -fv $SIGACS/tomweb-avant74050/webapps/hr-portlets/WEB-INF/view/disconnect.jsp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-portlets/WEB-INF/view/disconnect.jsp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-portlets/WEB-INF/view/disconnect.jsp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp -----> OK" >> ${LOGFILE}
fi
#SSO
echo "`date +%Y%m%d-%H:%M` :Report sso tomweb "  >> ${LOGFILE}
cp -vp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/sso* $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/ >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/sso* $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/ -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/sso* $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/ -----> OK" >> ${LOGFILE}
fi
cp -f $SIGACS/tomweb/webapps/hra-space/WEB-INF/views/login.jsp $SIGACS/tomweb/webapps/hra-space/WEB-INF/views/login-74020.jsp
if [ $? -ne 0 ]
then
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb/webapps/hra-space/WEB-INF/views/login.jsp $SIGACS/tomweb/webapps/hra-space/WEB-INF/views/login-74020.jsp -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb/webapps/hra-space/WEB-INF/views/login.jsp $SIGACS/tomweb/webapps/hra-space/WEB-INF/views/login-74020.jsp -----> OK" >> ${LOGFILE}
fi
cp -f $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/views/login.jsp $SIGACS/tomweb/webapps/hra-space/WEB-INF/views/login.jsp
if [ $? -ne 0 ]
then
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/views/login.jsp $SIGACS/tomweb/webapps/hra-space/WEB-INF/views/login.jsp -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/views/login.jsp $SIGACS/tomweb/webapps/hra-space/WEB-INF/views/login.jsp -----> OK" >> ${LOGFILE}
fi
cp -f $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/views/login.initial $SIGACS/tomweb/webapps/hra-space/WEB-INF/views
if [ $? -ne 0 ]
then
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/views/login.initial $SIGACS/tomweb/webapps/hra-space/WEB-INF/views -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/views/login.initial $SIGACS/tomweb/webapps/hra-space/WEB-INF/views -----> OK" >> ${LOGFILE}
fi
cp -f $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/views/login.maintenance $SIGACS/tomweb/webapps/hra-space/WEB-INF/views
if [ $? -ne 0 ]
then
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/views/login.maintenance $SIGACS/tomweb/webapps/hra-space/WEB-INF/views -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/views/login.maintenance $SIGACS/tomweb/webapps/hra-space/WEB-INF/views -----> OK" >> ${LOGFILE}
fi
cp -f $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/__* $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib
if [ $? -ne 0 ]
then
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/__* $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/__* $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib -----> OK" >> ${LOGFILE}
fi
#cp -vp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/web.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/ >> ${LOGFILE_BETA}
#if [ $? -ne 0 ]
#then
#  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/web.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/ -----> KO" >> ${LOGFILE}
#else
#  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/web.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/ -----> OK" >> ${LOGFILE}
#fi
###########################################################
}

Install_Tomtools () {

echo "*-------------------- STEP_N6-------------------------------------*" >> ${LOGFILE}
echo "*           Installation CONSOLE ADMIN ${VERSION}                  *" >> ${LOGFILE}
echo "*-----------------------------------------------------------------*" >> ${LOGFILE}
cd ~/
if [ ! -d "$SIGACS/tomtools-avant74050" ]
then
  cp -vpR ~/tomtools ~/tomtools-avant74050 >> ${LOGFILE_BETA}
  if [ $? -ne 0 ]
  then
    echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomtools vers $SIGACS/tomtools-avant74050 -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomtools vers $SIGACS/tomtools-avant74050 -----> OK" >> ${LOGFILE}
  fi
else
  echo "Copy Tomtools KO , sortie du script"
  exit 0
fi
rm -vfR $SIGACS/tomtools/webapps/hr-admin-console >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomtools/webapps/hr-admin-console -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomtools/webapps/hr-admin-console -----> OK" >> ${LOGFILE}
fi
cp -vR /admin/depot/esp/esp1.5/7.40.05002.0000/admin-console/hr-admin-console $SIGACS/tomtools/webapps >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/admin-console/hr-admin-console $SIGACS/tomtools/webapps -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/admin-console/hr-admin-console $SIGACS/tomtools/webapps -----> OK" >> ${LOGFILE}
fi
cp -vf $SIGACS/tomtools-avant74050/webapps/hr-admin-console/WEB-INF/conf/*.properties $SIGACS/tomtools/webapps/hr-admin-console/WEB-INF/conf >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomtools-avant74050/webapps/hr-admin-console/WEB-INF/conf/*.properties $SIGACS/tomtools/webapps/hr-admin-console/WEB-INF/conf -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy$SIGACS/tomtools-avant74050/webapps/hr-admin-console/WEB-INF/conf/*.properties $SIGACS/tomtools/webapps/hr-admin-console/WEB-INF/conf -----> OK" >> ${LOGFILE}
fi
rm -vf $SIGACS/tomtools/shared/lib/* >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomtools/shared/lib/* -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Remove $SIGACS/tomtools/shared/lib/* -----> OK" >> ${LOGFILE}
fi
cp -vf /admin/depot/esp/esp1.5/7.40.05002.0000/shared-libs/* $SIGACS/tomtools/shared/lib >> ${LOGFILE_BETA}
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/shared-libs/* $SIGACS/tomtools/shared/lib -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :Copy /admin/depot/esp/esp1.5/7.40.05002.0000/shared-libs/* $SIGACS/tomtools/shared/lib -----> OK" >> ${LOGFILE}
fi
}


Install_HF () {
echo " \n " >> ${LOGFILE} 
echo "*------------------ STEP_N7------------------------*" >> ${LOGFILE}
echo "*       Installation HF ${VERSION} *" >> ${LOGFILE}
echo "*--------------------------------------------------*" >> ${LOGFILE}
echo " \n " >> ${LOGFILE} 
cd ~/
#----------------------------------------------------------
echo "Pas de HF pour le moment.Merci de contacter IDKA" >> ${LOGFILE}
#HF01
#echo "HF01" >> ${LOGFILE}
#cp -f /admin/depot/hotfixes/7.40.05002.0000/01-224941/hrpro-navigation-darjeeling-ex.js $SIGACS/tomweb/webapps/hr-self-service/javascript
#if [ $? -ne 0 ]
#then
#	echo "`date +%Y%m%d-%H:%M` :Installation Hotfix 01-224941 -----> KO" >> ${LOGFILE}
#else
#	echo "`date +%Y%m%d-%H:%M` :Installation Hotfix 01-224941 -----> OK" >> ${LOGFILE}
#fi
}

MJ_PARAM () {

echo "*------------------ STEP_N8------------------------*" >> ${LOGFILE}
echo "*       GENERATION PARAM ${VERSION} *" >> ${LOGFILE}
echo "*--------------------------------------------------*" >> ${LOGFILE}
cd ~/
# fabrication de la collection ZZU74050  
. call_zcn
cat /admin/bin/runtools/inst7405002/upgrade74050-1.sql | sqlplus $HRUSER/$HRPSWD
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :fabrication de la collection ZZU74050 -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :fabrication de la collection ZZU74050 -----> OK" >> ${LOGFILE}
fi
#sauvegarde des parametre des npq
cat /admin/bin/runtools/inst7405002/upgrade74050-2.sql | sqlplus $HRUSER/$HRPSWD
if [ $? -ne 0 ]
then 
  echo "`date +%Y%m%d-%H:%M` :sauvegarde des parametre des npq -----> KO" >> ${LOGFILE}
else
  echo "`date +%Y%m%d-%H:%M` :sauvegarde des parametre des npq -----> OK" >> ${LOGFILE}
fi
if [ "$Prefix" = "pr" ]
then
  cat /admin/bin/runtools/inst7405002/upgrade74050-3.sql | sqlplus $HRUSER/$HRPSWD
  if [ $? -ne 0 ]
  then 
    echo "`date +%Y%m%d-%H:%M` :sauvegarde en plus des parametre des npq en prod  -----> KO" >> ${LOGFILE}
  else
    echo "`date +%Y%m%d-%H:%M` :sauvegarde en plus des parametre des npq en prod  -----> OK" >> ${LOGFILE}
  fi 
fi
}

Restart_CS () {

csadmin start cs
sleep 1
APROCESS=""
APROCESS=`ps -fu $LOGNAME | grep -v "grep" | grep AP0`
if [ "${APROCESS}" != "" ]
then
  pkill -u $LOGNAME -f AP0
fi
csadmin start cs
if [ $? -ne 0 ] ;then echo "`date +%Y%m%d-%H:%M` :csdamin start cs -----> KO" >> ${LOGFILE}
else  echo "`date +%Y%m%d-%H:%M` :csdamin start cs -----> OK" >> ${LOGFILE}
fi
}

Install_QUERY ()
{
COMMANDE="ksh /admin/bin/runtools/inst7405002/upgrade74050query.sh"
echo commande="$COMMANDE"

### sp�cifique cimpa : a mettre en avance pour s'ex�cuter correctement ####
if [ "$(hostname)" == "frsopslappv36" ]; then
        if [ "$(whoami)" == "v9dev" ] || [ "$(whoami)" == "v9rec" ]
                then
                        $COMMANDE
        fi
elif [ "$(hostname)" == "frsopslappv35" ]; then

        if [ "$(whoami)" == "v9prd" ]; then

			$COMMANDE
	fi
fi

####sp�cifique LCL-CASA-CACIB
if [ "$(hostname)" == "frsopslapp058" ] || [ "$(hostname)" == "frsopslapp057" ]
then
	$COMMANDE
	Restart_Specific
	Restart_CS
	exit	
fi

### sp�cifique sopra ch
if [ "$(hostname)" = "frsopslappv28" ]
then
  if [ "$(whoami)" = "v9rec" ]
  then
    $COMMANDE
  fi
fi
###

if [ "$EnvType" = "DV" ]
then
	ssh -n $EnvName@frsopslapp015 ". ~/.profile; $COMMANDE"
fi
if [ "$EnvType" = "QA" ]
then
	ssh -n $EnvName@frsopslapp016 ". ~/.profile; $COMMANDE"
fi
if [ "$Prefix" = "pr" ]
then
	ssh -n $EnvName@frsopslapp011 ". ~/.profile; $COMMANDE"
	ssh -n $EnvName@frsopslapp012 ". ~/.profile; $COMMANDE"
	ssh -n $EnvName@frsopslapp013 ". ~/.profile; $COMMANDE"
	ssh -n $EnvName@frsopslapp014 ". ~/.profile; $COMMANDE"
fi
if [ "$(whoami)" == "pr50" ] || [ "$(whoami)" == "pr163" ]
then
	ssh -n $EnvName@frsopslapp054 ". ~/.profile; $COMMANDE"
	ssh -n $EnvName@frsopslapp056 ". ~/.profile; $COMMANDE"
fi
}

Restart_Specific ()
{
echo "*------------------ STEP_N14------------------------*" >> ${LOGFILE}
echo "*       Resturation Specifique *" >> ${LOGFILE}
echo "*--------------------------------------------------*" >> ${LOGFILE}
#LCL-CASA-CACIB
if [ "$(hostname)" == "frsopslapp058" ] || [ "$(hostname)" == "frsopslapp057" ]
then
	echo "Restauration Specifique LCL-CASA-CACIB" >> ${LOGFILE}
	echo ""  >> ${LOGFILE}
	cp -fp $SIGACS/openhr-avant74050/lib/sso* $SIGACS/openhr/lib/
	if [ $? -ne 0 ]
	then
  		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/sso* $SIGACS/openhr/lib/ -----> KO" >> ${LOGFILE}
	else
  		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/sso* $SIGACS/openhr/lib/ -----> OK" >> ${LOGFILE}
	fi
	cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/hra-space-str_f.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes/ 
	if [ $? -ne 0 ]
	then
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/hra-space-str_f.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes/ -----> KO" >> ${LOGFILE}
	else
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/hra-space-str_f.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes/ -----> OK" >> ${LOGFILE}
	fi
	cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/acegi.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes/ 
	if [ $? -ne 0 ]
	then
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/acegi.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes/ -----> KO" >> ${LOGFILE}
	else
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/acegi.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes/ -----> OK" >> ${LOGFILE}
	fi
	cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/grant.properties $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes/ 
	if [ $? -ne 0 ]
	then
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/grant.properties $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes/ -----> KO" >> ${LOGFILE}
	else
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/grant.properties $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes/ -----> OK" >> ${LOGFILE}
	fi
	cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/vsj.properties $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes/ 
	if [ $? -ne 0 ]
	then
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/vsj.properties $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes/ -----> KO" >> ${LOGFILE}
	else
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/vsj.properties $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes/ -----> OK" >> ${LOGFILE}
	fi
	cp -p $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp_std 
	if [ $? -ne 0 ]
	then
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp_std -----> KO" >> ${LOGFILE}
	else
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp_std -----> OK" >> ${LOGFILE}
	fi
	cp -fp $SIGACS/tomweb-avant74050/webapps/hr-portlets/WEB-INF/view/disconnect.jsp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp 
	if [ $? -ne 0 ]
	then
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-portlets/WEB-INF/view/disconnect.jsp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp -----> KO" >> ${LOGFILE}
	else
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hr-portlets/WEB-INF/view/disconnect.jsp $SIGACS/tomweb/webapps/hr-portlets/WEB-INF/view/disconnect.jsp -----> OK" >> ${LOGFILE}
	fi
	cp -p $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/sso* $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/
	if [ $? -ne 0 ]
	then
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/sso* $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/ -----> KO" >> ${LOGFILE}
	else
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/sso* $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/ -----> OK" >> ${LOGFILE}
	fi
	cp -pf $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/applicationContext-sso.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/classes
	if [ $? -ne 0 ]
	then
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/applicationContext-sso.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/c
	lasses -----> KO" >> ${LOGFILE}
	else
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/classes/applicationContext-sso.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/c
	lasses -----> OK" >> ${LOGFILE}
	fi
	cp -pr $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/conf/sso $SIGACS/tomweb/webapps/hra-space/WEB-INF/conf
	if [ $? -ne 0 ]
	then
	   echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/conf/sso $SIGACS/tomweb/webapps/hra-space/WEB-INF/conf -----> KO" >> ${LOGFILE}
	else
	   echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/conf/sso $SIGACS/tomweb/webapps/hra-space/WEB-INF/conf -----> OK"
	fi
	cp -p $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/web.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/
	if [ $? -ne 0 ]
	then
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/web.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/ -----> KO" >> ${LOGFILE}
	else
	  echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/web.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/ -----> OK" >> ${LOGFILE}
	fi
fi
#NIDUS2
if [ "$(whoami)" == "pr131" ] || [ "$(whoami)" == "qa131" ]
then
	echo "Restauration Specifique NIDUS2(131)" >> ${LOGFILE}
	echo ""  >> ${LOGFILE}
	cp -fp $SIGACS/openhr-avant74050/lib/HRaCustomizationsSlice131* $SIGACS/openhr/lib/
	if [ $? -ne 0 ]
	then
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/HRaCustomizationsSlice131* -----> KO" >> ${LOGFILE}
	else
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/HRaCustomizationsSlice131* -----> OK" >> ${LOGFILE}
	fi
	cp -fp $SIGACS/openhr-avant74050/lib/archivos $SIGACS/openhr/lib/
	if [ $? -ne 0 ]
	then
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/archivos -----> KO" >> ${LOGFILE}
	else
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/archivos -----> OK" >> ${LOGFILE}
	fi
	cp -fp $SIGACS/openhr-avant74050/lib/blob.jar $SIGACS/openhr/lib/
	if [ $? -ne 0 ]
	then
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/blob.jar -----> KO" >> ${LOGFILE}
	else
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/blob.jar -----> OK" >> ${LOGFILE}
	fi
	cp -fp $SIGACS/openhr2-avant74050/lib/HRaCustomizationsSlice131* $SIGACS/openhr2/lib
	if [ $? -ne 0 ]
	then
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr2-avant74050/lib/HRaCustomizationsSlice131* -----> KO" >> ${LOGFILE}
	else
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr2-avant74050/lib/HRaCustomizationsSlice131* -----> OK" >> ${LOGFILE}
	fi
	cp -fp $SIGACS/openhr2-avant74050/lib/blob.jar $SIGACS/openhr2/lib
	if [ $? -ne 0 ]
	then
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr2-avant74050/lib/blob.jar -----> KO" >> ${LOGFILE}
	else
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr2-avant74050/lib/blob.jar -----> OK" >> ${LOGFILE}
	fi
	cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/HRaCustomizationsSlice131.jar $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/
	if [ $? -ne 0 ]
	then
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/HRaCustomizationsSlice131.jar -----> KO" >> ${LOGFILE}
	else
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/HRaCustomizationsSlice131.jar -----> OK"
 >> ${LOGFILE}
	fi
	cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/joda-time-1.5.2.jar $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/
	if [ $? -ne 0 ]
	then
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/joda-time-1.5.2.jar -----> KO" >> ${LOGFILE}
	else
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/joda-time-1.5.2.jar -----> OK" >> ${LOGFILE}
	fi
	cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/opensaml-2.6.1.jar $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/
	if [ $? -ne 0 ]
	then
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/opensaml-2.6.1.jar -----> KO" >> ${LOGFILE}
	else
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/opensaml-2.6.1.jar -----> OK" >> ${LOGFILE}
	fi
        cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/openws-1.5.1.jar $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/
        if [ $? -ne 0 ]
        then
                echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/openws-1.5.1.jar -----> KO" >> ${LOGFILE}
        else
                echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/openws-1.5.1.jar -----> OK" >> ${LOGFILE}
        fi
        cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/slf4j-api-1.7.7.jar $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/
        if [ $? -ne 0 ]
        then
                echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/slf4j-api-1.7.7.jar -----> KO" >> ${LOGFILE}
        else
                echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/slf4j-api-1.7.7.jar -----> OK" >> ${LOGFILE}
        fi
        cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/xmlsec-1.5.6.jar $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/
        if [ $? -ne 0 ]
        then
                echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/xmlsec-1.5.6.jar -----> KO" >> ${LOGFILE}
        else
                echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/xmlsec-1.5.6.jar -----> OK" >> ${LOGFILE}
        fi
        cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/xmltooling-1.4.1.jar $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/
        if [ $? -ne 0 ]
        then
                echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/xmltooling-1.4.1.jar -----> KO" >> ${LOGFILE}
        else
                echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/xmltooling-1.4.1.jar -----> OK" >> ${LOGFILE}
        fi
        cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/web.xml $SIGACS/tomweb/webapps/hra-space/WEB-INF/
        if [ $? -ne 0 ]
        then
                echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/web.xml -----> KO" >> ${LOGFILE}
        else
                echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/web.xml -----> OK" >> ${LOGFILE}
        fi
        cp -frp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/conf/* $SIGACS/tomweb/webapps/hra-space/WEB-INF/conf/
        if [ $? -ne 0 ]
        then
                echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/conf/* -----> KO" >> ${LOGFILE}
        else
                echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/conf/* -----> OK" >> ${LOGFILE}
        fi
fi
#GSK
if [ "$(whoami)" == "dv50" ] || [ "$(whoami)" == "qa50" ] || [ "$(whoami)" == "pr50" ]
then
	echo "Restauration Specifique GSK(50)" >> ${LOGFILE}
	echo ""  >> ${LOGFILE}
	cp -fp $SIGACS/openhr-avant74050/lib/_*  $SIGACS/openhr/lib/
	if [ $? -ne 0 ]
  	then
    		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/_*  -----> KO" >> ${LOGFILE}
 	else
    		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/_*  -----> OK" >> ${LOGFILE}
  	fi
	cp -fp $SIGACS/openhr-avant74050/lib/*saml* $SIGACS/openhr/lib/
	if [ $? -ne 0 ]
	then
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/*saml*  -----> KO" >> ${LOGFILE}
	else
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/lib/*saml*  -----> OK" >> ${LOGFILE}
	fi
	cp -pr $SIGACS/openhr-avant74050/conf/security $SIGACS/openhr/conf/
	if [ $? -ne 0 ]
	then
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/conf/security -----> KO" >> ${LOGFILE}
	else
		echo "`date +%Y%m%d-%H:%M` :Copy $SIGACS/openhr-avant74050/conf/security -----> OK" >> ${LOGFILE}
	fi
	cp -fp $SIGACS/tomweb-avant74050/webapps/hra-space/WEB-INF/lib/gsk-saml-web-1.0.jar $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/
	if [ $? -ne 0 ]
	then
		echo "`date +%Y%m%d-%H:%M` :Copy hra-space/WEB-INF/lib/gsk-saml-web-1.0.jar $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/ -----> KO" >> ${LOGFILE}
	else
		echo "`date +%Y%m%d-%H:%M` :Copy hra-space/WEB-INF/lib/gsk-saml-web-1.0.jar $SIGACS/tomweb/webapps/hra-space/WEB-INF/lib/ -----> OK" 
>> ${LOGFILE}
	fi
fi
#fin GSK
}
SNAP_PROCESS
STOP_SERVICES
SAVE_SERVICES
Install_Openhr
Install_Tomweb
Install_Tomtools
Install_HF
MJ_PARAM
Install_QUERY
Restart_Specific
Restart_CS
